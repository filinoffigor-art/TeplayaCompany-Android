/**
 * Тёплая Компания — v3.0.0
 * Google Apps Script backend for Android/WebView + Google Sheets + Google Drive.
 *
 * v3:
 * - динамические справочники из Google Sheets;
 * - бригады и участники бригад;
 * - зарплата каждому участнику на объекте;
 * - рабочие/выходные дни назначает инженер;
 * - монтажник не может заполнять будущие дни;
 * - обязательный цикл: начало → фото ДО → задачи → расходы/нет расходов → фото ПОСЛЕ → закрытие;
 * - аналитика рабочих дней и зарплаты;
 * - безопасное обновление структуры: существующие листы и данные не удаляются.
 */

var APP_VERSION = '3.0.0';
var TIMEZONE = 'Europe/Moscow';
var PROP_SPREADSHEET_ID = 'TK_SPREADSHEET_ID';
var PROP_PHOTO_FOLDER_ID = 'TK_PHOTO_FOLDER_ID';

var SHEET_OBJECTS = 'Объекты';
var SHEET_TX = 'Операции';
var SHEET_LISTS = 'Списки';
var SHEET_TEAMS = 'Бригады';
var SHEET_MEMBERS = 'Участники бригад';
var SHEET_ASSIGNMENTS = 'Задания монтажникам';
var SHEET_WORKDAYS = 'План работ';
var SHEET_PAYROLL = 'Начисления ЗП';
var SHEET_PHOTOS = 'Фото монтажей';

var OBJECT_HEADERS = ['ID','Создан','Изменен','Клиент','Телефон','Адрес','Вид работ','Сумма договора','Дата замера','Дата монтажа','Статус','Бригада','Ответственный','Комментарий'];
var TX_HEADERS = ['ID','Создан','ID объекта','Дата','Тип','Вид расхода','Статья','Сумма','Комментарий','Пользователь','Источник','Бригада','Фото чека'];
var LIST_HEADERS = ['Тип','Значение','Сортировка','Активно','ID'];
var TEAM_HEADERS = ['ID','Название','Активно','Создан','Изменен'];
var MEMBER_HEADERS = ['ID','ФИО','Телефон','ID бригады','Бригада','Активно','PIN','Создан','Изменен'];
var ASSIGNMENT_HEADERS = ['ID','Создан','Изменен','ID объекта','Бригада','Инженер','Дата начала','Время начала','План дней','Задание','Материалы','Инструменты','Важные указания','Статус','ID бригады','Состав (JSON)','ЗП бригады','Отправлено'];
var WORKDAY_HEADERS = ['ID','Создан','Изменен','ID задания','ID объекта','Бригада','День №','Дата','Заголовок','Задачи','Результат дня','Обязательные фото','Выполнено задач','Комментарий монтажника','Начало фактическое','Окончание фактическое','Статус','Широта старта','Долгота старта','Точность GPS, м','Тип дня','Расходы подтверждены','Кем подтверждены расходы','Комментарий инженера'];
var PAYROLL_HEADERS = ['ID','Создан','Изменен','ID задания','ID объекта','ID бригады','Бригада','ID участника','Участник','Сумма','Статус','Дата начисления','Дата выплаты','Комментарий'];
var PHOTO_HEADERS = ['ID','Создан','ID объекта','ID задания','ID дня','Бригада','Категория','Комментарий','Файл ID','Ссылка','Пользователь'];

function doGet() {
  return HtmlService.createTemplateFromFile('Index').evaluate()
    .setTitle('Тёплая Компания')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL)
    .addMetaTag('viewport','width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no');
}

function include(filename) { return HtmlService.createHtmlOutputFromFile(filename).getContent(); }

function setupApp() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  if (!ss) throw new Error('Откройте Apps Script из нужной Google Таблицы: Расширения → Apps Script.');
  PropertiesService.getScriptProperties().setProperty(PROP_SPREADSHEET_ID, ss.getId());
  ss.setSpreadsheetTimeZone(TIMEZONE);
  ensureStructure_(ss);
  seedLists_(ss);
  migrateTeamsFromLists_(ss);
  styleSheets_(ss);
  ensurePhotoRoot_();
  return {ok:true,version:APP_VERSION,spreadsheetId:ss.getId(),message:'Тёплая Компания v'+APP_VERSION+' готова. Данные сохранены.'};
}

function apiBootstrap() {
  var ss = getSpreadsheet_();
  ensureStructure_(ss);
  return buildBootstrap_(ss);
}

function apiSaveObject(p) {
  return withLock_(function(){
    p=p||{}; if(!clean_(p.clientName)) throw new Error('Укажите клиента.');
    var ss=getSpreadsheet_(); ensureStructure_(ss); var sh=ss.getSheetByName(SHEET_OBJECTS);
    var id=clean_(p.id)||makeId_('OBJ'); var row=findRow_(sh,'ID',id); var now=new Date();
    upsertByHeaders_(sh,row,{
      'ID':id,'Создан':row?getCellByHeader_(sh,row,'Создан'):now,'Изменен':now,
      'Клиент':clean_(p.clientName),'Телефон':clean_(p.phone),'Адрес':clean_(p.address),
      'Вид работ':clean_(p.workType),'Сумма договора':num_(p.contractAmount),
      'Дата замера':dateOrBlank_(p.measureDate),'Дата монтажа':dateOrBlank_(p.installDate),
      'Статус':clean_(p.status)||'Новая заявка','Бригада':clean_(p.team),
      'Ответственный':clean_(p.responsible),'Комментарий':clean_(p.comment)
    });
    return buildBootstrap_(ss);
  });
}

function apiAddTransaction(p) {
  return withLock_(function(){
    p=p||{}; if(['Приход','Расход'].indexOf(clean_(p.type))<0) throw new Error('Выберите тип операции.');
    if(num_(p.amount)<=0) throw new Error('Укажите сумму больше нуля.');
    var ss=getSpreadsheet_(); ensureStructure_(ss); appendTransaction_(ss,p,clean_(p.source)||'Офис',clean_(p.team),'');
    return buildBootstrap_(ss);
  });
}

function apiSaveListItem(p) {
  return withLock_(function(){
    p=p||{}; var type=clean_(p.type), value=clean_(p.value); if(!type||!value) throw new Error('Укажите тип и значение.');
    var ss=getSpreadsheet_(); var sh=ss.getSheetByName(SHEET_LISTS); var id=clean_(p.id)||makeId_('LST'); var row=findRow_(sh,'ID',id);
    upsertByHeaders_(sh,row,{'Тип':type,'Значение':value,'Сортировка':num_(p.sort)||100,'Активно':p.active===false?'Нет':'Да','ID':id});
    return buildBootstrap_(ss);
  });
}

function apiSaveTeam(p) {
  return withLock_(function(){
    p=p||{}; var name=clean_(p.name); if(!name) throw new Error('Введите название бригады.');
    var ss=getSpreadsheet_(); var sh=ss.getSheetByName(SHEET_TEAMS); var id=clean_(p.id)||makeId_('TEAM'); var row=findRow_(sh,'ID',id); var now=new Date();
    upsertByHeaders_(sh,row,{'ID':id,'Название':name,'Активно':p.active===false?'Нет':'Да','Создан':row?getCellByHeader_(sh,row,'Создан'):now,'Изменен':now});
    return buildBootstrap_(ss);
  });
}

function apiSaveMember(p) {
  return withLock_(function(){
    p=p||{}; var name=clean_(p.name); if(!name) throw new Error('Введите ФИО участника.');
    var ss=getSpreadsheet_(); var teams=readTeams_(ss); var teamId=clean_(p.teamId); var team=teams.filter(function(x){return x.id===teamId;})[0];
    if(!team) throw new Error('Выберите бригаду.');
    var sh=ss.getSheetByName(SHEET_MEMBERS); var id=clean_(p.id)||makeId_('MEM'); var row=findRow_(sh,'ID',id); var now=new Date();
    upsertByHeaders_(sh,row,{'ID':id,'ФИО':name,'Телефон':clean_(p.phone),'ID бригады':teamId,'Бригада':team.name,'Активно':p.active===false?'Нет':'Да','PIN':clean_(p.pin),'Создан':row?getCellByHeader_(sh,row,'Создан'):now,'Изменен':now});
    return buildBootstrap_(ss);
  });
}

function apiSaveAssignment(p) {
  return withLock_(function(){
    p=p||{}; var ss=getSpreadsheet_(); ensureStructure_(ss);
    if(!clean_(p.objectId)) throw new Error('Выберите объект.');
    var teams=readTeams_(ss), members=readMembers_(ss); var teamId=clean_(p.teamId); var team=teams.filter(function(x){return x.id===teamId;})[0];
    if(!team) throw new Error('Выберите бригаду.');
    var wages=(p.memberWages||[]).map(function(w){return {memberId:clean_(w.memberId),amount:num_(w.amount)};}).filter(function(w){return w.memberId;});
    if(!wages.length) throw new Error('Добавьте участников бригады и укажите зарплату.');
    var snapshots=[]; wages.forEach(function(w){
      var m=members.filter(function(x){return x.id===w.memberId && x.active;})[0]; if(!m) throw new Error('Участник бригады не найден: '+w.memberId);
      if(m.teamId!==teamId) throw new Error(m.name+' сейчас не состоит в выбранной бригаде.');
      if(w.amount<0) throw new Error('Зарплата не может быть отрицательной.');
      snapshots.push({memberId:m.id,name:m.name,amount:w.amount});
    });
    var sh=ss.getSheetByName(SHEET_ASSIGNMENTS); var id=clean_(p.id)||makeId_('JOB'); var row=findRow_(sh,'ID',id); var now=new Date(); var days=p.days||[];
    var plannedDays=Math.max(1,Number(p.plannedDays||days.length||1)); var totalWage=snapshots.reduce(function(s,x){return s+x.amount;},0);
    upsertByHeaders_(sh,row,{
      'ID':id,'Создан':row?getCellByHeader_(sh,row,'Создан'):now,'Изменен':now,'ID объекта':clean_(p.objectId),
      'Бригада':team.name,'Инженер':clean_(p.engineer)||'Инженер','Дата начала':dateOrBlank_(p.startDate),
      'Время начала':clean_(p.startTime)||'09:00','План дней':plannedDays,'Задание':clean_(p.workSummary),
      'Материалы':clean_(p.materials),'Инструменты':clean_(p.tools),'Важные указания':clean_(p.notes),
      'Статус':clean_(p.status)||'Запланировано','ID бригады':team.id,'Состав (JSON)':JSON.stringify(snapshots),
      'ЗП бригады':totalWage,'Отправлено':now
    });
    upsertWorkDaysV3_(ss,id,p,team,days,plannedDays);
    upsertPayroll_(ss,id,p.objectId,team,snapshots);
    syncObjectFromAssignment_(ss,p.objectId,team.name,p.engineer,p.startDate);
    return buildBootstrap_(ss);
  });
}

function apiSetWorkDayType(p) {
  return withLock_(function(){
    p=p||{}; var ss=getSpreadsheet_(); var sh=ss.getSheetByName(SHEET_WORKDAYS); var row=findRow_(sh,'ID',clean_(p.id)); if(!row) throw new Error('День не найден.');
    var type=clean_(p.dayType)==='Выходной'?'Выходной':'Рабочий';
    setCellByHeader_(sh,row,'Тип дня',type); setCellByHeader_(sh,row,'Изменен',new Date());
    if(type==='Выходной') { setCellByHeader_(sh,row,'Статус','Выходной'); setCellByHeader_(sh,row,'Комментарий инженера',clean_(p.engineerComment)); }
    else if(clean_(getCellByHeader_(sh,row,'Статус'))==='Выходной') setCellByHeader_(sh,row,'Статус','Запланирован');
    return buildBootstrap_(ss);
  });
}

function apiUpdateWorkDayProgress(p) {
  return withLock_(function(){
    p=p||{}; var ss=getSpreadsheet_(); var sh=ss.getSheetByName(SHEET_WORKDAYS); var row=findRow_(sh,'ID',clean_(p.id)); if(!row) throw new Error('День плана не найден.');
    assertEditableDay_(sh,row);
    var action=clean_(p.action)||'save', now=new Date(); var started=getCellByHeader_(sh,row,'Начало фактическое'), finished=getCellByHeader_(sh,row,'Окончание фактическое');
    if(action==='start') { if(!started) started=now; setCellByHeader_(sh,row,'Статус','В работе'); setCellByHeader_(sh,row,'Начало фактическое',started); setCellByHeader_(sh,row,'Широта старта',num_(p.lat)||''); setCellByHeader_(sh,row,'Долгота старта',num_(p.lng)||''); setCellByHeader_(sh,row,'Точность GPS, м',num_(p.accuracy)||''); }
    if(action==='finish') {
      validateFinishDay_(ss,sh,row);
      if(!started) started=now; finished=now; setCellByHeader_(sh,row,'Начало фактическое',started); setCellByHeader_(sh,row,'Окончание фактическое',finished); setCellByHeader_(sh,row,'Статус','Завершён');
      maybeCompleteAssignment_(ss,clean_(getCellByHeader_(sh,row,'ID задания')));
    }
    setCellByHeader_(sh,row,'Выполнено задач',JSON.stringify(p.completedTasks||[]));
    setCellByHeader_(sh,row,'Комментарий монтажника',clean_(p.comment));
    setCellByHeader_(sh,row,'Изменен',now);
    return buildBootstrap_(ss);
  });
}

function apiConfirmExpenses(p) {
  return withLock_(function(){
    p=p||{}; var ss=getSpreadsheet_(); var sh=ss.getSheetByName(SHEET_WORKDAYS); var row=findRow_(sh,'ID',clean_(p.workDayId)); if(!row) throw new Error('День не найден.');
    assertEditableDay_(sh,row); setCellByHeader_(sh,row,'Расходы подтверждены','Да'); setCellByHeader_(sh,row,'Кем подтверждены расходы',clean_(p.user)||clean_(getCellByHeader_(sh,row,'Бригада'))); setCellByHeader_(sh,row,'Изменен',new Date());
    return buildBootstrap_(ss);
  });
}

function apiAddCrewExpense(p) {
  return withLock_(function(){
    p=p||{}; if(num_(p.amount)<=0) throw new Error('Укажите сумму расхода.'); if(!clean_(p.category)) throw new Error('Выберите статью расхода.');
    var ss=getSpreadsheet_(), wd=ss.getSheetByName(SHEET_WORKDAYS), row=findRow_(wd,'ID',clean_(p.workDayId)); if(!row) throw new Error('День работ не найден.'); assertEditableDay_(wd,row);
    var receiptUrl=''; if(clean_(p.receiptDataUrl)) receiptUrl=savePhotoFile_({objectId:p.objectId,assignmentId:p.assignmentId,workDayId:p.workDayId,team:p.team,category:'Чек',note:p.comment,dataUrl:p.receiptDataUrl,fileName:p.receiptFileName||'receipt.jpg',user:p.user}).fileUrl;
    appendTransaction_(ss,{objectId:p.objectId,date:p.date||toISODate_(getCellByHeader_(wd,row,'Дата')),type:'Расход',expenseKind:'Расход по объекту',category:p.category,amount:p.amount,comment:p.comment,user:p.user},'Монтажник',p.team,receiptUrl);
    setCellByHeader_(wd,row,'Расходы подтверждены','Да'); setCellByHeader_(wd,row,'Кем подтверждены расходы',clean_(p.user)||clean_(p.team));
    return buildBootstrap_(ss);
  });
}

function apiUploadCrewPhoto(p) {
  return withLock_(function(){
    p=p||{}; if(!clean_(p.dataUrl)) throw new Error('Выберите фотографию.');
    var ss=getSpreadsheet_(), wd=ss.getSheetByName(SHEET_WORKDAYS), row=findRow_(wd,'ID',clean_(p.workDayId)); if(!row) throw new Error('День работ не найден.'); assertEditableDay_(wd,row);
    savePhotoFile_(p); return buildBootstrap_(ss);
  });
}

function apiUpdatePayrollStatus(p) {
  return withLock_(function(){
    p=p||{}; var allowed=['Запланировано','Начислено','Выплачено']; var status=clean_(p.status); if(allowed.indexOf(status)<0) throw new Error('Неверный статус ЗП.');
    var ss=getSpreadsheet_(), sh=ss.getSheetByName(SHEET_PAYROLL), row=findRow_(sh,'ID',clean_(p.id)); if(!row) throw new Error('Начисление не найдено.');
    setCellByHeader_(sh,row,'Статус',status); setCellByHeader_(sh,row,'Изменен',new Date()); if(status==='Начислено') setCellByHeader_(sh,row,'Дата начисления',new Date()); if(status==='Выплачено') setCellByHeader_(sh,row,'Дата выплаты',new Date());
    return buildBootstrap_(ss);
  });
}

/* -------------------------- Build bootstrap -------------------------- */
function buildBootstrap_(ss) {
  var objects=readObjects_(ss), tx=readTransactions_(ss), lists=readLists_(ss), teams=readTeams_(ss), members=readMembers_(ss), assignments=readAssignments_(ss), workdays=readWorkDays_(ss), payroll=readPayroll_(ss), photos=readPhotos_(ss);
  var objMap={}; objects.forEach(function(o){objMap[o.id]=o; o.received=0;o.expenses=0;o.debt=0;o.projectedProfit=0;});
  tx.forEach(function(t){var o=objMap[t.objectId]; if(o){if(t.type==='Приход')o.received+=t.amount;else if(t.type==='Расход')o.expenses+=t.amount;}});
  objects.forEach(function(o){o.debt=Math.max(0,o.contractAmount-o.received);o.projectedProfit=o.contractAmount-o.expenses;});
  var totals={contracts:sum_(objects,'contractAmount'),received:sum_(objects,'received'),expenses:tx.filter(function(x){return x.type==='Расход';}).reduce(function(s,x){return s+x.amount;},0),activeObjects:objects.filter(function(x){return ['Монтаж завершён','Закрыт','Отказ'].indexOf(x.status)<0;}).length};
  totals.projectedProfit=totals.contracts-totals.expenses;
  var today=todayISO_();
  var eng={assignments:assignments.length,activeAssignments:assignments.filter(function(a){return ['Завершено','Отменено'].indexOf(a.status)<0;}).length,todayDays:workdays.filter(function(d){return d.date===today&&d.dayType!=='Выходной';}).length,daysOff:workdays.filter(function(d){return d.date===today&&d.dayType==='Выходной';}).length,overdueDays:workdays.filter(function(d){return d.date<today&&d.dayType!=='Выходной'&&d.status!=='Завершён';}).length,photos:photos.length};
  var crewAnalytics=buildCrewAnalytics_(members,assignments,workdays,payroll,objMap);
  return {ok:true,version:APP_VERSION,serverDate:today,objects:objects,transactions:tx,lists:lists,teams:teams,members:members,assignments:assignments,workdays:workdays,payroll:payroll,photos:photos,totals:totals,engineerTotals:eng,crewAnalytics:crewAnalytics};
}

function buildCrewAnalytics_(members,assignments,workdays,payroll,objMap) {
  var map={}; members.forEach(function(m){map[m.id]={memberId:m.id,name:m.name,teamId:m.teamId,team:m.team,workingDays:0,daysOff:0,completedDays:0,salary:0,paid:0,objects:{}};});
  assignments.forEach(function(a){(a.members||[]).forEach(function(ms){if(map[ms.memberId])map[ms.memberId].objects[a.objectId]=true;});});
  workdays.forEach(function(d){var a=assignments.filter(function(x){return x.id===d.assignmentId;})[0]; if(!a)return; (a.members||[]).forEach(function(ms){var x=map[ms.memberId];if(!x)return; if(d.dayType==='Выходной')x.daysOff++; else if(d.startedAt||d.status==='Завершён'){x.workingDays++;if(d.status==='Завершён')x.completedDays++;}});});
  payroll.forEach(function(p){var x=map[p.memberId]; if(x){x.salary+=p.amount; if(p.status==='Выплачено')x.paid+=p.amount;}});
  Object.keys(map).forEach(function(k){var x=map[k];x.objectCount=Object.keys(x.objects).length;x.averagePerWorkingDay=x.workingDays?Math.round(x.salary/x.workingDays):0;delete x.objects;});
  return Object.keys(map).map(function(k){return map[k];});
}

/* -------------------------- Readers -------------------------- */
function readObjects_(ss){return readRows_(ss.getSheetByName(SHEET_OBJECTS)).map(function(r){return{id:s_(r['ID']),createdAt:isoDateTime_(r['Создан']),updatedAt:isoDateTime_(r['Изменен']),clientName:s_(r['Клиент']),phone:s_(r['Телефон']),address:s_(r['Адрес']),workType:s_(r['Вид работ']),contractAmount:num_(r['Сумма договора']),measureDate:toISODate_(r['Дата замера']),installDate:toISODate_(r['Дата монтажа']),status:s_(r['Статус']),team:s_(r['Бригада']),responsible:s_(r['Ответственный']),comment:s_(r['Комментарий'])};}).filter(function(x){return x.id;});}
function readTransactions_(ss){return readRows_(ss.getSheetByName(SHEET_TX)).map(function(r){return{id:s_(r['ID']),createdAt:isoDateTime_(r['Создан']),objectId:s_(r['ID объекта']),date:toISODate_(r['Дата']),type:s_(r['Тип']),expenseKind:s_(r['Вид расхода']),category:s_(r['Статья']),amount:num_(r['Сумма']),comment:s_(r['Комментарий']),user:s_(r['Пользователь']),source:s_(r['Источник']),team:s_(r['Бригада']),receiptUrl:s_(r['Фото чека'])};}).filter(function(x){return x.id;});}
function readLists_(ss){var grouped={};readRows_(ss.getSheetByName(SHEET_LISTS)).forEach(function(r){if(!isActive_(r['Активно']))return;var t=s_(r['Тип']),v=s_(r['Значение']);if(!t||!v)return;if(!grouped[t])grouped[t]=[];grouped[t].push({id:s_(r['ID']),value:v,sort:num_(r['Сортировка'])||100});});Object.keys(grouped).forEach(function(k){grouped[k].sort(function(a,b){return a.sort-b.sort||a.value.localeCompare(b.value);});grouped[k]=grouped[k].map(function(x){return x.value;});});return{statuses:grouped['Статус']||[],workTypes:grouped['Вид работ']||[],responsibles:grouped['Ответственный']||[],expenseCategories:grouped['Статья расхода']||[],photoCategories:grouped['Категория фото']||[],raw:readRows_(ss.getSheetByName(SHEET_LISTS)).map(function(r){return{id:s_(r['ID']),type:s_(r['Тип']),value:s_(r['Значение']),sort:num_(r['Сортировка']),active:isActive_(r['Активно'])};})};}
function readTeams_(ss){return readRows_(ss.getSheetByName(SHEET_TEAMS)).map(function(r){return{id:s_(r['ID']),name:s_(r['Название']),active:isActive_(r['Активно']),createdAt:isoDateTime_(r['Создан']),updatedAt:isoDateTime_(r['Изменен'])};}).filter(function(x){return x.id&&x.name;});}
function readMembers_(ss){return readRows_(ss.getSheetByName(SHEET_MEMBERS)).map(function(r){return{id:s_(r['ID']),name:s_(r['ФИО']),phone:s_(r['Телефон']),teamId:s_(r['ID бригады']),team:s_(r['Бригада']),active:isActive_(r['Активно']),pin:s_(r['PIN'])};}).filter(function(x){return x.id&&x.name;});}
function readAssignments_(ss){return readRows_(ss.getSheetByName(SHEET_ASSIGNMENTS)).map(function(r){return{id:s_(r['ID']),createdAt:isoDateTime_(r['Создан']),updatedAt:isoDateTime_(r['Изменен']),objectId:s_(r['ID объекта']),team:s_(r['Бригада']),engineer:s_(r['Инженер']),startDate:toISODate_(r['Дата начала']),startTime:s_(r['Время начала']),plannedDays:num_(r['План дней']),workSummary:s_(r['Задание']),materials:s_(r['Материалы']),tools:s_(r['Инструменты']),notes:s_(r['Важные указания']),status:s_(r['Статус']),teamId:s_(r['ID бригады']),members:json_(r['Состав (JSON)'],[]),teamWage:num_(r['ЗП бригады']),sentAt:isoDateTime_(r['Отправлено'])};}).filter(function(x){return x.id;});}
function readWorkDays_(ss){return readRows_(ss.getSheetByName(SHEET_WORKDAYS)).map(function(r){return{id:s_(r['ID']),assignmentId:s_(r['ID задания']),objectId:s_(r['ID объекта']),team:s_(r['Бригада']),dayNumber:num_(r['День №']),date:toISODate_(r['Дата']),title:s_(r['Заголовок']),tasks:linesOrJson_(r['Задачи']),result:s_(r['Результат дня']),requiredPhotos:linesOrJson_(r['Обязательные фото']),completedTasks:json_(r['Выполнено задач'],[]),installerComment:s_(r['Комментарий монтажника']),startedAt:isoDateTime_(r['Начало фактическое']),finishedAt:isoDateTime_(r['Окончание фактическое']),status:s_(r['Статус'])||'Запланирован',lat:numOrBlank_(r['Широта старта']),lng:numOrBlank_(r['Долгота старта']),accuracy:numOrBlank_(r['Точность GPS, м']),dayType:s_(r['Тип дня'])||'Рабочий',expensesConfirmed:isYes_(r['Расходы подтверждены']),expenseConfirmedBy:s_(r['Кем подтверждены расходы']),engineerComment:s_(r['Комментарий инженера'])};}).filter(function(x){return x.id;});}
function readPayroll_(ss){return readRows_(ss.getSheetByName(SHEET_PAYROLL)).map(function(r){return{id:s_(r['ID']),assignmentId:s_(r['ID задания']),objectId:s_(r['ID объекта']),teamId:s_(r['ID бригады']),team:s_(r['Бригада']),memberId:s_(r['ID участника']),memberName:s_(r['Участник']),amount:num_(r['Сумма']),status:s_(r['Статус'])||'Запланировано',accruedDate:toISODate_(r['Дата начисления']),paidDate:toISODate_(r['Дата выплаты']),comment:s_(r['Комментарий'])};}).filter(function(x){return x.id;});}
function readPhotos_(ss){return readRows_(ss.getSheetByName(SHEET_PHOTOS)).map(function(r){return{id:s_(r['ID']),createdAt:isoDateTime_(r['Создан']),objectId:s_(r['ID объекта']),assignmentId:s_(r['ID задания']),workDayId:s_(r['ID дня']),team:s_(r['Бригада']),category:s_(r['Категория']),note:s_(r['Комментарий']),fileId:s_(r['Файл ID']),fileUrl:s_(r['Ссылка']),thumbnailUrl:s_(r['Ссылка']),user:s_(r['Пользователь'])};}).filter(function(x){return x.id;});}

/* -------------------------- Assignment helpers -------------------------- */
function upsertWorkDaysV3_(ss,assignmentId,p,team,days,plannedDays){
  var sh=ss.getSheetByName(SHEET_WORKDAYS), start=dateOrBlank_(p.startDate)||new Date(), existing=readRows_(sh).filter(function(r){return s_(r['ID задания'])===assignmentId;}); var now=new Date();
  for(var i=0;i<plannedDays;i++){
    var d=days[i]||{}, dayNo=i+1, ex=existing.filter(function(r){return num_(r['День №'])===dayNo;})[0], row=ex?ex.__row:null, id=ex?s_(ex['ID']):makeId_('DAY');
    var dt=d.date?dateOrBlank_(d.date):addDays_(start,i); var dayType=clean_(d.dayType)==='Выходной'?'Выходной':'Рабочий'; var prevStatus=row?s_(getCellByHeader_(sh,row,'Статус')):''; var status=dayType==='Выходной'?'Выходной':(['В работе','Завершён'].indexOf(prevStatus)>=0?prevStatus:'Запланирован');
    upsertByHeaders_(sh,row,{'ID':id,'Создан':row?getCellByHeader_(sh,row,'Создан'):now,'Изменен':now,'ID задания':assignmentId,'ID объекта':clean_(p.objectId),'Бригада':team.name,'День №':dayNo,'Дата':dt,'Заголовок':clean_(d.title)||(dayType==='Выходной'?'Выходной':'День '+dayNo),'Задачи':JSON.stringify(array_(d.tasks)),'Результат дня':clean_(d.result),'Обязательные фото':JSON.stringify(array_(d.requiredPhotos).length?array_(d.requiredPhotos):['До работ','После работ']),'Выполнено задач':row?getCellByHeader_(sh,row,'Выполнено задач'):'[]','Комментарий монтажника':row?getCellByHeader_(sh,row,'Комментарий монтажника'):'','Начало фактическое':row?getCellByHeader_(sh,row,'Начало фактическое'):'','Окончание фактическое':row?getCellByHeader_(sh,row,'Окончание фактическое'):'','Статус':status,'Тип дня':dayType,'Расходы подтверждены':row?getCellByHeader_(sh,row,'Расходы подтверждены'):'Нет','Кем подтверждены расходы':row?getCellByHeader_(sh,row,'Кем подтверждены расходы'):'','Комментарий инженера':clean_(d.engineerComment)});
  }
  // Лишние будущие строки задания не удаляем, если по ним уже была фактическая работа; иначе удаляем.
  for(var r=sh.getLastRow();r>=2;r--){if(s_(getCellByHeader_(sh,r,'ID задания'))===assignmentId && num_(getCellByHeader_(sh,r,'День №'))>plannedDays && !getCellByHeader_(sh,r,'Начало фактическое'))sh.deleteRow(r);}
}
function upsertPayroll_(ss,assignmentId,objectId,team,snapshots){var sh=ss.getSheetByName(SHEET_PAYROLL), now=new Date(); snapshots.forEach(function(m){var row=findRowBy2_(sh,'ID задания',assignmentId,'ID участника',m.memberId), id=row?s_(getCellByHeader_(sh,row,'ID')):makeId_('PAY'), oldStatus=row?s_(getCellByHeader_(sh,row,'Статус')):'Запланировано';upsertByHeaders_(sh,row,{'ID':id,'Создан':row?getCellByHeader_(sh,row,'Создан'):now,'Изменен':now,'ID задания':assignmentId,'ID объекта':clean_(objectId),'ID бригады':team.id,'Бригада':team.name,'ID участника':m.memberId,'Участник':m.name,'Сумма':m.amount,'Статус':oldStatus||'Запланировано'});});}
function syncObjectFromAssignment_(ss,objectId,team,engineer,startDate){var sh=ss.getSheetByName(SHEET_OBJECTS),row=findRow_(sh,'ID',clean_(objectId));if(!row)return;setCellByHeader_(sh,row,'Изменен',new Date());setCellByHeader_(sh,row,'Дата монтажа',dateOrBlank_(startDate));setCellByHeader_(sh,row,'Статус','Запланирован монтаж');setCellByHeader_(sh,row,'Бригада',team);setCellByHeader_(sh,row,'Ответственный',clean_(engineer)||'Инженер');}
function maybeCompleteAssignment_(ss,assignmentId){if(!assignmentId)return;var wd=readWorkDays_(ss).filter(function(d){return d.assignmentId===assignmentId&&d.dayType!=='Выходной';});if(!wd.length||wd.some(function(d){return d.status!=='Завершён';}))return;var sh=ss.getSheetByName(SHEET_ASSIGNMENTS),row=findRow_(sh,'ID',assignmentId);if(row)setCellByHeader_(sh,row,'Статус','Завершено');var payroll=ss.getSheetByName(SHEET_PAYROLL);for(var r=2;r<=payroll.getLastRow();r++){if(s_(getCellByHeader_(payroll,r,'ID задания'))===assignmentId&&s_(getCellByHeader_(payroll,r,'Статус'))==='Запланировано'){setCellByHeader_(payroll,r,'Статус','Начислено');setCellByHeader_(payroll,r,'Дата начисления',new Date());}}}
function validateFinishDay_(ss,sh,row){var id=s_(getCellByHeader_(sh,row,'ID')), photos=readPhotos_(ss).filter(function(p){return p.workDayId===id;}), cats=photos.map(function(p){return p.category;});if(cats.indexOf('До работ')<0)throw new Error('Сначала добавьте фото ДО работ.');if(!isYes_(getCellByHeader_(sh,row,'Расходы подтверждены')))throw new Error('Подтвердите расходы: внесите расход или нажмите «Расходов нет».');if(cats.indexOf('После работ')<0)throw new Error('Добавьте фото ПОСЛЕ работ.');}
function assertEditableDay_(sh,row){var type=s_(getCellByHeader_(sh,row,'Тип дня'))||'Рабочий';if(type==='Выходной')throw new Error('Этот день инженер отметил как выходной.');var d=toISODate_(getCellByHeader_(sh,row,'Дата'));if(d>todayISO_())throw new Error('Будущий день заблокирован. Он станет доступен '+d+'.');}

/* -------------------------- Transactions / photos -------------------------- */
function appendTransaction_(ss,p,source,team,receiptUrl){var sh=ss.getSheetByName(SHEET_TX),now=new Date(),id=clean_(p.id)||makeId_('TX'),row=findRow_(sh,'ID',id),type=clean_(p.type),expenseKind=type==='Расход'?(clean_(p.expenseKind)||'Расход по объекту'):'';upsertByHeaders_(sh,row,{'ID':id,'Создан':row?getCellByHeader_(sh,row,'Создан'):now,'ID объекта':clean_(p.objectId),'Дата':dateOrBlank_(p.date)||now,'Тип':type,'Вид расхода':expenseKind,'Статья':clean_(p.category),'Сумма':num_(p.amount),'Комментарий':clean_(p.comment),'Пользователь':clean_(p.user),'Источник':source||'Офис','Бригада':clean_(team),'Фото чека':clean_(receiptUrl)});}
function savePhotoFile_(p){var parsed=parseDataUrl_(p.dataUrl),folder=ensurePhotoRoot_(),name=(clean_(p.fileName)||('photo_'+Date.now()+'.jpg')).replace(/[^0-9A-Za-zА-Яа-яЁё._-]+/g,'_'),blob=Utilities.newBlob(parsed.bytes,parsed.mime,name),file=folder.createFile(blob);try{file.setSharing(DriveApp.Access.ANYONE_WITH_LINK,DriveApp.Permission.VIEW);}catch(e){}var sh=getSpreadsheet_().getSheetByName(SHEET_PHOTOS),id=makeId_('PH');upsertByHeaders_(sh,null,{'ID':id,'Создан':new Date(),'ID объекта':clean_(p.objectId),'ID задания':clean_(p.assignmentId),'ID дня':clean_(p.workDayId),'Бригада':clean_(p.team),'Категория':clean_(p.category)||'В процессе','Комментарий':clean_(p.note),'Файл ID':file.getId(),'Ссылка':file.getUrl(),'Пользователь':clean_(p.user)||clean_(p.team)});return{id:id,fileId:file.getId(),fileUrl:file.getUrl()};}
function parseDataUrl_(dataUrl){var m=String(dataUrl||'').match(/^data:([^;]+);base64,(.+)$/);if(!m)throw new Error('Неверный формат фотографии.');return{mime:m[1],bytes:Utilities.base64Decode(m[2])};}

/* -------------------------- Structure / migration -------------------------- */
function ensureStructure_(ss){ensureSheet_(ss,SHEET_OBJECTS,OBJECT_HEADERS);ensureSheet_(ss,SHEET_TX,TX_HEADERS);ensureSheet_(ss,SHEET_LISTS,LIST_HEADERS);ensureSheet_(ss,SHEET_TEAMS,TEAM_HEADERS);ensureSheet_(ss,SHEET_MEMBERS,MEMBER_HEADERS);ensureSheet_(ss,SHEET_ASSIGNMENTS,ASSIGNMENT_HEADERS);ensureSheet_(ss,SHEET_WORKDAYS,WORKDAY_HEADERS);ensureSheet_(ss,SHEET_PAYROLL,PAYROLL_HEADERS);ensureSheet_(ss,SHEET_PHOTOS,PHOTO_HEADERS);}
function ensureSheet_(ss,name,headers){var sh=ss.getSheetByName(name);if(!sh){sh=ss.insertSheet(name);sh.getRange(1,1,1,headers.length).setValues([headers]);return sh;}if(sh.getLastColumn()<1){sh.getRange(1,1,1,headers.length).setValues([headers]);return sh;}var existing=sh.getRange(1,1,1,Math.max(1,sh.getLastColumn())).getDisplayValues()[0].map(s_);if(existing.filter(Boolean).length===0){sh.getRange(1,1,1,headers.length).setValues([headers]);return sh;}headers.forEach(function(h){if(existing.indexOf(h)<0){var c=sh.getLastColumn()+1;sh.getRange(1,c).setValue(h);existing.push(h);}});return sh;}
function seedLists_(ss){var sh=ss.getSheetByName(SHEET_LISTS), rows=readRows_(sh), defaults={
'Статус':['Новая заявка','Замер назначен','Замер проведён','КП отправлено','Договор','Запланирован монтаж','В работе','Монтаж завершён','Закрыт','Отказ'],
'Вид работ':['Утепление','Утепление пола','Утепление чердака','Утепление мансарды','Утепление скатов','Утепление стен','Фасадные работы','Кровельные работы','Внутренняя отделка'],
'Ответственный':['Игорь','Константин','Инженер'],
'Статья расхода':['Материалы','Монтажные работы','Зарплата','Доставка','Топливо','Инструмент','Прочее'],
'Категория фото':['До работ','В процессе','После работ','Проблема','Чек','Подпись клиента']};
Object.keys(defaults).forEach(function(t){if(rows.some(function(r){return s_(r['Тип'])===t;}))return;defaults[t].forEach(function(v,i){upsertByHeaders_(sh,null,{'Тип':t,'Значение':v,'Сортировка':(i+1)*10,'Активно':'Да','ID':makeId_('LST')});});});}
function migrateTeamsFromLists_(ss){var tsh=ss.getSheetByName(SHEET_TEAMS);if(tsh.getLastRow()>1)return;var rows=readRows_(ss.getSheetByName(SHEET_LISTS)).filter(function(r){return ['Бригада','Бригады'].indexOf(s_(r['Тип']))>=0&&isActive_(r['Активно']);});rows.forEach(function(r){var now=new Date();upsertByHeaders_(tsh,null,{'ID':makeId_('TEAM'),'Название':s_(r['Значение']),'Активно':'Да','Создан':now,'Изменен':now});});}
function styleSheets_(ss){[SHEET_OBJECTS,SHEET_TX,SHEET_LISTS,SHEET_TEAMS,SHEET_MEMBERS,SHEET_ASSIGNMENTS,SHEET_WORKDAYS,SHEET_PAYROLL,SHEET_PHOTOS].forEach(function(n){var sh=ss.getSheetByName(n);if(!sh)return;sh.setFrozenRows(1);var lc=sh.getLastColumn();if(lc)sh.getRange(1,1,1,lc).setFontWeight('bold').setBackground('#267672').setFontColor('#ffffff');});}
function ensurePhotoRoot_(){var props=PropertiesService.getScriptProperties(),id=props.getProperty(PROP_PHOTO_FOLDER_ID);if(id){try{return DriveApp.getFolderById(id);}catch(e){}}var f=DriveApp.createFolder('Тёплая Компания — Фото монтажей');props.setProperty(PROP_PHOTO_FOLDER_ID,f.getId());return f;}

/* -------------------------- Generic helpers -------------------------- */
function getSpreadsheet_(){var id=PropertiesService.getScriptProperties().getProperty(PROP_SPREADSHEET_ID);if(id)return SpreadsheetApp.openById(id);var ss=SpreadsheetApp.getActiveSpreadsheet();if(!ss)throw new Error('Сначала выполните setupApp() из таблицы.');return ss;}
function readRows_(sh){if(!sh||sh.getLastRow()<2)return[];var lc=sh.getLastColumn(), headers=sh.getRange(1,1,1,lc).getDisplayValues()[0].map(s_), vals=sh.getRange(2,1,sh.getLastRow()-1,lc).getValues();return vals.map(function(row,i){var o={__row:i+2};headers.forEach(function(h,j){if(h)o[h]=row[j];});return o;}).filter(function(o){return Object.keys(o).some(function(k){return k!=='__row'&&s_(o[k])!=='';});});}
function headerMap_(sh){var vals=sh.getRange(1,1,1,sh.getLastColumn()).getDisplayValues()[0],m={};vals.forEach(function(v,i){m[s_(v)]=i+1;});return m;}
function upsertByHeaders_(sh,row,obj){var map=headerMap_(sh);if(!row){row=sh.getLastRow()+1;}Object.keys(obj).forEach(function(k){if(map[k])sh.getRange(row,map[k]).setValue(obj[k]);});return row;}
function getCellByHeader_(sh,row,h){var c=headerMap_(sh)[h];return c?sh.getRange(row,c).getValue():'';}
function setCellByHeader_(sh,row,h,v){var c=headerMap_(sh)[h];if(c)sh.getRange(row,c).setValue(v);}
function findRow_(sh,h,val){var c=headerMap_(sh)[h];if(!c||sh.getLastRow()<2)return null;var vals=sh.getRange(2,c,sh.getLastRow()-1,1).getDisplayValues();for(var i=0;i<vals.length;i++)if(s_(vals[i][0])===s_(val))return i+2;return null;}
function findRowBy2_(sh,h1,v1,h2,v2){var rows=readRows_(sh);for(var i=0;i<rows.length;i++)if(s_(rows[i][h1])===s_(v1)&&s_(rows[i][h2])===s_(v2))return rows[i].__row;return null;}
function withLock_(fn){var l=LockService.getScriptLock();l.waitLock(30000);try{return fn();}finally{l.releaseLock();}}
function makeId_(p){return p+'-'+Utilities.formatDate(new Date(),TIMEZONE,'yyyyMMddHHmmss')+'-'+Math.floor(Math.random()*9000+1000);}
function clean_(v){return String(v==null?'':v).trim();} function s_(v){return clean_(v);} function num_(v){if(typeof v==='number')return isFinite(v)?v:0;var n=Number(String(v==null?'':v).replace(/\s/g,'').replace(',','.').replace(/[^0-9.\-]/g,''));return isFinite(n)?n:0;} function numOrBlank_(v){return clean_(v)===''?'':num_(v);}
function isActive_(v){var s=clean_(v).toLowerCase();return s===''||['да','true','1','активно','yes'].indexOf(s)>=0;} function isYes_(v){return ['да','true','1','yes'].indexOf(clean_(v).toLowerCase())>=0;}
function dateOrBlank_(v){if(!v)return'';if(Object.prototype.toString.call(v)==='[object Date]'&&!isNaN(v))return v;var d=new Date(v);return isNaN(d)?'':d;}
function toISODate_(v){if(!v)return'';var d=dateOrBlank_(v);if(!d)return clean_(v).slice(0,10);return Utilities.formatDate(d,TIMEZONE,'yyyy-MM-dd');}
function isoDateTime_(v){if(!v)return'';var d=dateOrBlank_(v);return d?Utilities.formatDate(d,TIMEZONE,"yyyy-MM-dd'T'HH:mm:ssXXX"):'';}
function todayISO_(){return Utilities.formatDate(new Date(),TIMEZONE,'yyyy-MM-dd');}
function addDays_(d,n){var x=new Date(d.getTime());x.setDate(x.getDate()+n);return x;}
function json_(v,fallback){if(v==null||v==='')return fallback;try{return typeof v==='string'?JSON.parse(v):v;}catch(e){return fallback;}}
function linesOrJson_(v){if(Array.isArray(v))return v;if(!v)return[];var j=json_(v,null);if(Array.isArray(j))return j;return String(v).split(/\r?\n/).map(clean_).filter(Boolean);}
function array_(v){if(Array.isArray(v))return v.map(clean_).filter(Boolean);if(!v)return[];return String(v).split(/\r?\n|\s*;\s*/).map(clean_).filter(Boolean);}
function sum_(arr,key){return arr.reduce(function(s,x){return s+num_(x[key]);},0);}
