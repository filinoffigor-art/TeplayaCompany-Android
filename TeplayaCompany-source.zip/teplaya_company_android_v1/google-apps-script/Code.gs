/**
 * Тёплая Компания — мобильное приложение v2.0
 * Google Apps Script + Google Sheets + Google Drive
 *
 * Новое в v2:
 * - модуль «Инженер»: задания бригадам и план-график по дням;
 * - режим «Монтажник»: задания на сегодня, чек-лист, фотоотчёт, расходы;
 * - фото «до / в процессе / после / чек» сохраняются в Google Drive;
 * - все действия автоматически прикрепляются к объекту в основном приложении.
 *
 * Обновление с v1:
 * 1) замените Code.gs и Index.html;
 * 2) один раз снова запустите setupApp();
 * 3) обновите развертывание веб-приложения.
 * Существующие вкладки «Объекты», «Операции», «Списки» сохраняются.
 */

var APP_VERSION = '2.0.0';
var PROP_SPREADSHEET_ID = 'TK_SPREADSHEET_ID';
var PROP_PHOTO_FOLDER_ID = 'TK_PHOTO_FOLDER_ID';
var SHEET_OBJECTS = 'Объекты';
var SHEET_TX = 'Операции';
var SHEET_LISTS = 'Списки';
var SHEET_ASSIGNMENTS = 'Задания монтажникам';
var SHEET_WORKDAYS = 'План работ';
var SHEET_PHOTOS = 'Фото монтажей';
var TIMEZONE = 'Europe/Moscow';

var OBJECT_HEADERS = [
  'ID', 'Создан', 'Изменен', 'Клиент', 'Телефон', 'Адрес', 'Вид работ',
  'Сумма договора', 'Дата замера', 'Дата монтажа', 'Статус', 'Бригада',
  'Ответственный', 'Комментарий'
];

// Первые 10 колонок полностью совместимы с v1. Новые поля добавляются справа.
var TX_HEADERS = [
  'ID', 'Создан', 'ID объекта', 'Дата', 'Тип', 'Вид расхода', 'Статья',
  'Сумма', 'Комментарий', 'Пользователь', 'Источник', 'Бригада', 'Фото чека'
];

var LIST_HEADERS = ['Тип', 'Значение', 'Сортировка', 'Активно'];

var ASSIGNMENT_HEADERS = [
  'ID', 'Создан', 'Изменен', 'ID объекта', 'Бригада', 'Инженер',
  'Дата начала', 'Время начала', 'План дней', 'Задание', 'Материалы',
  'Инструменты', 'Важные указания', 'Статус'
];

var WORKDAY_HEADERS = [
  'ID', 'Создан', 'Изменен', 'ID задания', 'ID объекта', 'Бригада',
  'День №', 'Дата', 'Заголовок', 'Задачи', 'Результат дня',
  'Обязательные фото', 'Выполнено задач', 'Комментарий монтажника',
  'Начало фактическое', 'Окончание фактическое', 'Статус',
  'Широта старта', 'Долгота старта', 'Точность GPS, м'
];

var PHOTO_HEADERS = [
  'ID', 'Создан', 'ID объекта', 'ID задания', 'ID дня', 'Бригада',
  'Категория', 'Комментарий', 'Файл ID', 'Ссылка', 'Пользователь'
];

function doGet() {
  return HtmlService.createTemplateFromFile('Index')
    .evaluate()
    .setTitle('Тёплая Компания')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no');
}

function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

/**
 * Первичная настройка или безопасное обновление v1 -> v2.
 * Запустить вручную один раз после замены файлов.
 */
function setupApp() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  if (!ss) throw new Error('Откройте Apps Script из нужной Google Таблицы: Расширения → Apps Script.');

  PropertiesService.getScriptProperties().setProperty(PROP_SPREADSHEET_ID, ss.getId());
  ss.setSpreadsheetTimeZone(TIMEZONE);
  ensureAppStructure_(ss);
  applyFormats_(
    ss.getSheetByName(SHEET_OBJECTS), ss.getSheetByName(SHEET_TX), ss.getSheetByName(SHEET_LISTS),
    ss.getSheetByName(SHEET_ASSIGNMENTS), ss.getSheetByName(SHEET_WORKDAYS), ss.getSheetByName(SHEET_PHOTOS)
  );
  applyValidations_(ss.getSheetByName(SHEET_OBJECTS));
  ensurePhotoRoot_();

  return {
    ok: true,
    message: 'Готово. Приложение обновлено до версии ' + APP_VERSION + '.',
    spreadsheetId: ss.getId(),
    version: APP_VERSION
  };
}

function apiBootstrap() {
  var ss = getSpreadsheet_();
  ensureAppStructure_(ss);

  var objects = readObjects_(ss);
  var transactions = readTransactions_(ss);
  var lists = readLists_(ss);
  var assignments = readAssignments_(ss);
  var workdays = readWorkDays_(ss);
  var photos = readPhotos_(ss);

  return buildBootstrap_(objects, transactions, lists, assignments, workdays, photos);
}

function apiSaveObject(payload) {
  return withLock_(function () {
    validateObjectPayload_(payload);
    var ss = getSpreadsheet_();
    ensureAppStructure_(ss);
    var sh = ss.getSheetByName(SHEET_OBJECTS);
    var now = new Date();
    var id = cleanText_(payload.id) || makeId_('OBJ');
    var row = findRowById_(sh, id);

    var values = [
      id,
      row ? sh.getRange(row, 2).getValue() : now,
      now,
      cleanText_(payload.clientName),
      cleanPhone_(payload.phone),
      cleanText_(payload.address),
      cleanText_(payload.workType),
      toNumber_(payload.contractAmount),
      toDateOrBlank_(payload.measureDate),
      toDateOrBlank_(payload.installDate),
      cleanText_(payload.status) || 'Новая заявка',
      cleanText_(payload.team),
      cleanText_(payload.responsible),
      cleanText_(payload.comment)
    ];

    writeRow_(sh, row, values, OBJECT_HEADERS.length);
    formatObjectRow_(sh, row || sh.getLastRow());
    return apiBootstrap();
  });
}

function apiDeleteObject(id) {
  return withLock_(function () {
    id = cleanText_(id);
    if (!id) throw new Error('Не передан ID объекта.');
    var ss = getSpreadsheet_();
    deleteRowsByColumn_(ss.getSheetByName(SHEET_TX), 3, id);
    deleteRowsByColumn_(ss.getSheetByName(SHEET_ASSIGNMENTS), 4, id);
    deleteRowsByColumn_(ss.getSheetByName(SHEET_WORKDAYS), 5, id);
    deleteRowsByColumn_(ss.getSheetByName(SHEET_PHOTOS), 3, id);
    var row = findRowById_(ss.getSheetByName(SHEET_OBJECTS), id);
    if (row) ss.getSheetByName(SHEET_OBJECTS).deleteRow(row);
    return apiBootstrap();
  });
}

function apiUpdateStatus(id, status) {
  return withLock_(function () {
    var ss = getSpreadsheet_();
    var sh = ss.getSheetByName(SHEET_OBJECTS);
    var row = findRowById_(sh, cleanText_(id));
    if (!row) throw new Error('Объект не найден.');
    sh.getRange(row, 11).setValue(cleanText_(status));
    sh.getRange(row, 3).setValue(new Date());
    return apiBootstrap();
  });
}

function apiAddTransaction(payload) {
  return withLock_(function () {
    validateTransactionPayload_(payload);
    var ss = getSpreadsheet_();
    ensureAppStructure_(ss);
    appendTransaction_(ss, payload, 'Офис', '', '');
    return apiBootstrap();
  });
}

/** Расход, внесённый монтажником. Чек можно передать фотографией data:image/...;base64,... */
function apiAddCrewExpense(payload) {
  return withLock_(function () {
    if (!payload) throw new Error('Нет данных расхода.');
    var objectId = cleanText_(payload.objectId);
    var team = cleanText_(payload.team);
    if (!objectId) throw new Error('Не выбран объект.');
    if (!team) throw new Error('Не выбрана бригада.');
    if (toNumber_(payload.amount) <= 0) throw new Error('Укажите сумму больше нуля.');
    if (!cleanText_(payload.category)) throw new Error('Выберите статью расхода.');

    var receiptUrl = '';
    if (cleanText_(payload.receiptDataUrl)) {
      var saved = savePhotoFile_({
        objectId: objectId,
        assignmentId: cleanText_(payload.assignmentId),
        workDayId: cleanText_(payload.workDayId),
        team: team,
        category: 'Чек',
        note: 'Чек: ' + cleanText_(payload.comment),
        dataUrl: payload.receiptDataUrl,
        fileName: cleanText_(payload.receiptFileName) || 'receipt.jpg',
        user: cleanText_(payload.user) || team
      });
      receiptUrl = saved.fileUrl;
    }

    var ss = getSpreadsheet_();
    ensureAppStructure_(ss);
    appendTransaction_(ss, {
      objectId: objectId,
      date: payload.date,
      type: 'Расход',
      expenseKind: 'Расход по объекту',
      category: payload.category,
      amount: payload.amount,
      comment: payload.comment,
      user: payload.user || team
    }, 'Монтажник', team, receiptUrl);
    return apiBootstrap();
  });
}

function appendTransaction_(ss, payload, source, team, receiptUrl) {
  var sh = ss.getSheetByName(SHEET_TX);
  var now = new Date();
  var id = cleanText_(payload.id) || makeId_('TX');
  var row = findRowById_(sh, id);
  var type = cleanText_(payload.type);
  var expenseKind = type === 'Расход' ? (cleanText_(payload.expenseKind) || 'Расход по объекту') : '';
  var objectId = cleanText_(payload.objectId);
  if (type === 'Приход' && !objectId) throw new Error('Для прихода выберите объект.');
  if (type === 'Расход' && expenseKind === 'Расход по объекту' && !objectId) throw new Error('Для расхода по объекту выберите объект.');
  if (expenseKind === 'Прочий расход по статье') objectId = '';

  var values = [
    id,
    row ? sh.getRange(row, 2).getValue() : now,
    objectId,
    toDateOrBlank_(payload.date) || now,
    type,
    expenseKind,
    cleanText_(payload.category),
    toNumber_(payload.amount),
    cleanText_(payload.comment),
    cleanText_(payload.user),
    cleanText_(source || payload.source || 'Офис'),
    cleanText_(team || payload.team),
    cleanText_(receiptUrl || payload.receiptUrl)
  ];
  writeRow_(sh, row, values, TX_HEADERS.length);
  formatTransactionRow_(sh, row || sh.getLastRow());
}

function apiDeleteTransaction(id) {
  return withLock_(function () {
    var ss = getSpreadsheet_();
    var sh = ss.getSheetByName(SHEET_TX);
    var row = findRowById_(sh, cleanText_(id));
    if (row) sh.deleteRow(row);
    return apiBootstrap();
  });
}

/** Инженер создаёт/обновляет задание и подробный план по дням. */
function apiSaveAssignment(payload) {
  return withLock_(function () {
    validateAssignmentPayload_(payload);
    var ss = getSpreadsheet_();
    ensureAppStructure_(ss);
    var sh = ss.getSheetByName(SHEET_ASSIGNMENTS);
    var now = new Date();
    var id = cleanText_(payload.id) || makeId_('JOB');
    var row = findRowById_(sh, id);
    var oldStatus = row ? cleanText_(sh.getRange(row, 14).getValue()) : '';
    var status = oldStatus === 'В работе' || oldStatus === 'Завершено' ? oldStatus : (cleanText_(payload.status) || 'Запланировано');
    var days = payload.days || [];
    var plannedDays = Math.max(1, Number(payload.plannedDays || days.length || 1));

    var values = [
      id,
      row ? sh.getRange(row, 2).getValue() : now,
      now,
      cleanText_(payload.objectId),
      cleanText_(payload.team),
      cleanText_(payload.engineer),
      toDateOrBlank_(payload.startDate),
      cleanText_(payload.startTime) || '09:00',
      plannedDays,
      cleanText_(payload.workSummary),
      cleanText_(payload.materials),
      cleanText_(payload.tools),
      cleanText_(payload.notes),
      status
    ];
    writeRow_(sh, row, values, ASSIGNMENT_HEADERS.length);
    formatAssignmentRow_(sh, row || sh.getLastRow());

    upsertWorkDays_(ss, id, payload, days, plannedDays);

    // Синхронизируем объект: бригада, дата монтажа, ответственный и статус.
    var objSh = ss.getSheetByName(SHEET_OBJECTS);
    var objRow = findRowById_(objSh, cleanText_(payload.objectId));
    if (objRow) {
      objSh.getRange(objRow, 3).setValue(now);
      objSh.getRange(objRow, 10).setValue(toDateOrBlank_(payload.startDate));
      objSh.getRange(objRow, 11).setValue(status === 'В работе' ? 'В работе' : 'Запланирован монтаж');
      objSh.getRange(objRow, 12).setValue(cleanText_(payload.team));
      objSh.getRange(objRow, 13).setValue(cleanText_(payload.engineer) || 'Инженер');
    }
    return apiBootstrap();
  });
}

function apiDeleteAssignment(id) {
  return withLock_(function () {
    id = cleanText_(id);
    var ss = getSpreadsheet_();
    deleteRowsByColumn_(ss.getSheetByName(SHEET_WORKDAYS), 4, id);
    var row = findRowById_(ss.getSheetByName(SHEET_ASSIGNMENTS), id);
    if (row) ss.getSheetByName(SHEET_ASSIGNMENTS).deleteRow(row);
    return apiBootstrap();
  });
}

/** Монтажник запускает день, сохраняет чек-лист или завершает день. */
function apiUpdateWorkDayProgress(payload) {
  return withLock_(function () {
    if (!payload || !cleanText_(payload.id)) throw new Error('Не передан день плана.');
    var ss = getSpreadsheet_();
    ensureAppStructure_(ss);
    var sh = ss.getSheetByName(SHEET_WORKDAYS);
    var row = findRowById_(sh, cleanText_(payload.id));
    if (!row) throw new Error('День плана не найден.');

    var completed = payload.completedTasks || [];
    var action = cleanText_(payload.action) || 'save';
    var now = new Date();
    var status = cleanText_(sh.getRange(row, 17).getValue()) || 'Запланирован';
    var started = sh.getRange(row, 15).getValue();
    var finished = sh.getRange(row, 16).getValue();

    if (action === 'start') {
      if (!started) started = now;
      status = 'В работе';
    } else if (action === 'finish') {
      if (!started) started = now;
      finished = now;
      status = 'Завершён';
    } else if (action === 'reopen') {
      finished = '';
      status = 'В работе';
    }

    sh.getRange(row, 3).setValue(now);
    sh.getRange(row, 13).setValue(JSON.stringify(completed));
    sh.getRange(row, 14).setValue(cleanText_(payload.comment));
    sh.getRange(row, 15).setValue(started || '');
    sh.getRange(row, 16).setValue(finished || '');
    sh.getRange(row, 17).setValue(status);
    if (action === 'start' && payload.location) {
      sh.getRange(row, 18).setValue(toNumber_(payload.location.lat));
      sh.getRange(row, 19).setValue(toNumber_(payload.location.lng));
      sh.getRange(row, 20).setValue(toNumber_(payload.location.accuracy));
    }
    formatWorkDayRow_(sh, row);

    syncAssignmentAndObjectStatus_(ss, cleanText_(sh.getRange(row, 4).getValue()), cleanText_(sh.getRange(row, 5).getValue()));
    return apiBootstrap();
  });
}

/** Фото монтажника: до / в процессе / после / проблема / чек. */
function apiUploadPhoto(payload) {
  return withLock_(function () {
    if (!payload) throw new Error('Нет данных фотографии.');
    if (!cleanText_(payload.objectId)) throw new Error('Не выбран объект.');
    if (!cleanText_(payload.dataUrl)) throw new Error('Фотография не передана.');
    savePhotoFile_(payload);
    return apiBootstrap();
  });
}

function savePhotoFile_(payload) {
  var parsed = parseDataUrl_(payload.dataUrl);
  var root = ensurePhotoRoot_();
  var objectId = cleanText_(payload.objectId);
  var folder = ensureChildFolder_(root, objectId);
  var ext = mimeExtension_(parsed.mime);
  var baseName = cleanFileName_(payload.fileName || ('photo-' + Utilities.formatDate(new Date(), TIMEZONE, 'yyyyMMdd-HHmmss') + ext));
  if (baseName.toLowerCase().slice(-ext.length) !== ext) baseName += ext;
  var blob = Utilities.newBlob(parsed.bytes, parsed.mime, baseName);
  var file = folder.createFile(blob);

  // Для мобильного WebView нужна ссылка, открываемая без отдельной Google-авторизации.
  // В Workspace политика домена может запретить общий доступ — тогда файл останется приватным.
  try { file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW); } catch (ignored) {}

  var fileUrl = 'https://drive.google.com/file/d/' + file.getId() + '/view';
  var sh = getSpreadsheet_().getSheetByName(SHEET_PHOTOS);
  sh.appendRow([
    makeId_('PH'), new Date(), objectId, cleanText_(payload.assignmentId), cleanText_(payload.workDayId),
    cleanText_(payload.team), cleanText_(payload.category) || 'В процессе', cleanText_(payload.note),
    file.getId(), fileUrl, cleanText_(payload.user) || cleanText_(payload.team)
  ]);
  formatPhotoRow_(sh, sh.getLastRow());
  return { fileId: file.getId(), fileUrl: fileUrl };
}

function apiSaveListItem(payload) {
  return withLock_(function () {
    var type = cleanText_(payload.type);
    var value = cleanText_(payload.value);
    if (!type || !value) throw new Error('Укажите тип и значение.');
    var ss = getSpreadsheet_();
    var sh = ss.getSheetByName(SHEET_LISTS);
    sh.appendRow([type, value, sh.getLastRow(), true]);
    return apiBootstrap();
  });
}

function getSpreadsheet_() {
  var id = PropertiesService.getScriptProperties().getProperty(PROP_SPREADSHEET_ID);
  if (!id) throw new Error('Приложение ещё не настроено. Запустите setupApp() один раз из редактора Apps Script.');
  return SpreadsheetApp.openById(id);
}

function ensureAppStructure_(ss) {
  var objects = ensureSheet_(ss, SHEET_OBJECTS, OBJECT_HEADERS);
  var tx = ensureSheet_(ss, SHEET_TX, TX_HEADERS);
  var lists = ensureSheet_(ss, SHEET_LISTS, LIST_HEADERS);
  var assignments = ensureSheet_(ss, SHEET_ASSIGNMENTS, ASSIGNMENT_HEADERS);
  var workdays = ensureSheet_(ss, SHEET_WORKDAYS, WORKDAY_HEADERS);
  var photos = ensureSheet_(ss, SHEET_PHOTOS, PHOTO_HEADERS);

  seedLists_(lists);
}

/**
 * Не удаляет старые данные. При обновлении v1 недостающие колонки просто добавляются справа.
 */
function ensureSheet_(ss, name, headers) {
  var sh = ss.getSheetByName(name);
  if (!sh) sh = ss.insertSheet(name);
  if (sh.getMaxColumns() < headers.length) sh.insertColumnsAfter(sh.getMaxColumns(), headers.length - sh.getMaxColumns());
  for (var i = 0; i < headers.length; i++) {
    var cell = sh.getRange(1, i + 1);
    var current = cleanText_(cell.getDisplayValue());
    if (!current || current !== headers[i]) cell.setValue(headers[i]);
  }
  return sh;
}

function styleSheet_(sh, columns) {
  sh.setFrozenRows(1);
  sh.getRange(1, 1, 1, columns)
    .setFontWeight('bold').setBackground('#153e75').setFontColor('#ffffff').setHorizontalAlignment('center');
  sh.setRowHeight(1, 34);
  sh.getDataRange().setVerticalAlignment('middle');
}

function applyFormats_(objects, tx, lists, assignments, workdays, photos) {
  styleSheet_(objects, OBJECT_HEADERS.length);
  styleSheet_(tx, TX_HEADERS.length);
  styleSheet_(lists, LIST_HEADERS.length);
  styleSheet_(assignments, ASSIGNMENT_HEADERS.length);
  styleSheet_(workdays, WORKDAY_HEADERS.length);
  styleSheet_(photos, PHOTO_HEADERS.length);

  objects.setColumnWidths(1, OBJECT_HEADERS.length, 130);
  objects.setColumnWidth(4, 190); objects.setColumnWidth(6, 260); objects.setColumnWidth(14, 300);
  objects.getRange('B:C').setNumberFormat('dd.MM.yyyy HH:mm'); objects.getRange('H:H').setNumberFormat('#,##0.00 ₽'); objects.getRange('I:J').setNumberFormat('dd.MM.yyyy');

  tx.setColumnWidths(1, TX_HEADERS.length, 130); tx.setColumnWidth(9, 280); tx.setColumnWidth(13, 260);
  tx.getRange('B:B').setNumberFormat('dd.MM.yyyy HH:mm'); tx.getRange('D:D').setNumberFormat('dd.MM.yyyy'); tx.getRange('H:H').setNumberFormat('#,##0.00 ₽');

  assignments.setColumnWidths(1, ASSIGNMENT_HEADERS.length, 140);
  assignments.setColumnWidth(10, 360); assignments.setColumnWidth(11, 300); assignments.setColumnWidth(12, 300); assignments.setColumnWidth(13, 300);
  assignments.getRange('B:C').setNumberFormat('dd.MM.yyyy HH:mm'); assignments.getRange('G:G').setNumberFormat('dd.MM.yyyy');

  workdays.setColumnWidths(1, WORKDAY_HEADERS.length, 135);
  workdays.setColumnWidth(10, 420); workdays.setColumnWidth(11, 320); workdays.setColumnWidth(12, 260); workdays.setColumnWidth(14, 320);
  workdays.getRange('B:C').setNumberFormat('dd.MM.yyyy HH:mm'); workdays.getRange('H:H').setNumberFormat('dd.MM.yyyy'); workdays.getRange('O:P').setNumberFormat('dd.MM.yyyy HH:mm');
  workdays.getRange('R:T').setNumberFormat('0.000000');

  photos.setColumnWidths(1, PHOTO_HEADERS.length, 140); photos.setColumnWidth(8, 320); photos.setColumnWidth(10, 360);
  photos.getRange('B:B').setNumberFormat('dd.MM.yyyy HH:mm');
}

function applyValidations_(objects) {
  var lists = readLists_(getSpreadsheet_());
  if (lists.workTypes.length) objects.getRange('G2:G').setDataValidation(SpreadsheetApp.newDataValidation().requireValueInList(lists.workTypes, true).build());
  if (lists.statuses.length) objects.getRange('K2:K').setDataValidation(SpreadsheetApp.newDataValidation().requireValueInList(lists.statuses, true).build());
  if (lists.teams.length) objects.getRange('L2:L').setDataValidation(SpreadsheetApp.newDataValidation().requireValueInList(lists.teams, true).build());
  if (lists.responsibles.length) objects.getRange('M2:M').setDataValidation(SpreadsheetApp.newDataValidation().requireValueInList(lists.responsibles, true).build());
}

function seedLists_(sh) {
  ensureListValues_(sh, 'status', [
    'Новая заявка', 'Замер назначен', 'Замер проведён', 'КП отправлено', 'Договор',
    'Запланирован монтаж', 'В работе', 'Монтаж завершён', 'Закрыт', 'Отказ'
  ]);
  ensureListValues_(sh, 'workType', [
    'Утепление', 'Утепление пола', 'Утепление чердака', 'Утепление мансарды',
    'Утепление скатов', 'Утепление стен', 'Фасадные работы', 'Кровельные работы', 'Внутренняя отделка'
  ]);
  ensureListValues_(sh, 'team', ['Бригада 1', 'Бригада 2', 'Бригада 3', 'Бригада 4']);
  ensureListValues_(sh, 'responsible', ['Игорь', 'Константин', 'Инженер']);
  ensureListValues_(sh, 'expenseCategory', [
    'Материалы', 'Монтажные работы', 'Зарплата', 'Доставка', 'Топливо', 'Аренда',
    'Реклама', 'Инструмент', 'Связь', 'Кредиты', 'Налоги', 'Прочее'
  ]);
  ensureListValues_(sh, 'photoCategory', ['До работ', 'В процессе', 'После работ', 'Проблема', 'Чек', 'Подпись клиента']);
}

function ensureListValues_(sh, type, values) {
  var existing = {};
  if (sh.getLastRow() > 1) {
    sh.getRange(2, 1, sh.getLastRow() - 1, 2).getDisplayValues().forEach(function (r) {
      if (r[0] === type) existing[r[1]] = true;
    });
  }
  var rows = [];
  values.forEach(function (v, i) { if (!existing[v]) rows.push([type, v, i + 1, true]); });
  if (rows.length) sh.getRange(sh.getLastRow() + 1, 1, rows.length, 4).setValues(rows);
}

function readObjects_(ss) {
  var sh = ss.getSheetByName(SHEET_OBJECTS);
  if (!sh || sh.getLastRow() <= 1) return [];
  return sh.getRange(2, 1, sh.getLastRow() - 1, OBJECT_HEADERS.length).getValues().filter(function (r) { return r[0]; }).map(function (r) {
    return {
      id: String(r[0]), createdAt: dateIso_(r[1]), updatedAt: dateIso_(r[2]), clientName: String(r[3] || ''), phone: String(r[4] || ''),
      address: String(r[5] || ''), workType: String(r[6] || ''), contractAmount: Number(r[7] || 0), measureDate: dateOnly_(r[8]), installDate: dateOnly_(r[9]),
      status: String(r[10] || ''), team: String(r[11] || ''), responsible: String(r[12] || ''), comment: String(r[13] || '')
    };
  });
}

function readTransactions_(ss) {
  var sh = ss.getSheetByName(SHEET_TX);
  if (!sh || sh.getLastRow() <= 1) return [];
  return sh.getRange(2, 1, sh.getLastRow() - 1, TX_HEADERS.length).getValues().filter(function (r) { return r[0]; }).map(function (r) {
    return {
      id: String(r[0]), createdAt: dateIso_(r[1]), objectId: String(r[2] || ''), date: dateOnly_(r[3]), type: String(r[4] || ''),
      expenseKind: String(r[5] || ''), category: String(r[6] || ''), amount: Number(r[7] || 0), comment: String(r[8] || ''), user: String(r[9] || ''),
      source: String(r[10] || ''), team: String(r[11] || ''), receiptUrl: String(r[12] || '')
    };
  });
}

function readLists_(ss) {
  var sh = ss.getSheetByName(SHEET_LISTS);
  var out = { statuses: [], workTypes: [], teams: [], responsibles: [], expenseCategories: [], photoCategories: [] };
  if (!sh || sh.getLastRow() <= 1) return out;
  var rows = sh.getRange(2, 1, sh.getLastRow() - 1, LIST_HEADERS.length).getValues();
  rows.sort(function (a, b) { return Number(a[2] || 0) - Number(b[2] || 0); });
  rows.forEach(function (r) {
    if (r[3] === false || String(r[3]).toLowerCase() === 'false') return;
    var type = String(r[0] || ''), value = String(r[1] || ''); if (!value) return;
    if (type === 'status') out.statuses.push(value);
    if (type === 'workType') out.workTypes.push(value);
    if (type === 'team') out.teams.push(value);
    if (type === 'responsible') out.responsibles.push(value);
    if (type === 'expenseCategory') out.expenseCategories.push(value);
    if (type === 'photoCategory') out.photoCategories.push(value);
  });
  return out;
}

function readAssignments_(ss) {
  var sh = ss.getSheetByName(SHEET_ASSIGNMENTS);
  if (!sh || sh.getLastRow() <= 1) return [];
  return sh.getRange(2, 1, sh.getLastRow() - 1, ASSIGNMENT_HEADERS.length).getValues().filter(function (r) { return r[0]; }).map(function (r) {
    return {
      id: String(r[0]), createdAt: dateIso_(r[1]), updatedAt: dateIso_(r[2]), objectId: String(r[3] || ''), team: String(r[4] || ''), engineer: String(r[5] || ''),
      startDate: dateOnly_(r[6]), startTime: String(r[7] || ''), plannedDays: Number(r[8] || 1), workSummary: String(r[9] || ''), materials: String(r[10] || ''),
      tools: String(r[11] || ''), notes: String(r[12] || ''), status: String(r[13] || 'Запланировано')
    };
  });
}

function readWorkDays_(ss) {
  var sh = ss.getSheetByName(SHEET_WORKDAYS);
  if (!sh || sh.getLastRow() <= 1) return [];
  return sh.getRange(2, 1, sh.getLastRow() - 1, WORKDAY_HEADERS.length).getValues().filter(function (r) { return r[0]; }).map(function (r) {
    return {
      id: String(r[0]), createdAt: dateIso_(r[1]), updatedAt: dateIso_(r[2]), assignmentId: String(r[3] || ''), objectId: String(r[4] || ''), team: String(r[5] || ''),
      dayNumber: Number(r[6] || 1), date: dateOnly_(r[7]), title: String(r[8] || ''), tasks: lines_(r[9]), result: String(r[10] || ''), requiredPhotos: listText_(r[11]),
      completedTasks: jsonArray_(r[12]), installerComment: String(r[13] || ''), startedAt: dateIso_(r[14]), finishedAt: dateIso_(r[15]), status: String(r[16] || 'Запланирован'),
      startLat: Number(r[17] || 0), startLng: Number(r[18] || 0), startAccuracy: Number(r[19] || 0)
    };
  });
}

function readPhotos_(ss) {
  var sh = ss.getSheetByName(SHEET_PHOTOS);
  if (!sh || sh.getLastRow() <= 1) return [];
  return sh.getRange(2, 1, sh.getLastRow() - 1, PHOTO_HEADERS.length).getValues().filter(function (r) { return r[0]; }).map(function (r) {
    var fileId = String(r[8] || '');
    return {
      id: String(r[0]), createdAt: dateIso_(r[1]), objectId: String(r[2] || ''), assignmentId: String(r[3] || ''), workDayId: String(r[4] || ''), team: String(r[5] || ''),
      category: String(r[6] || ''), note: String(r[7] || ''), fileId: fileId, fileUrl: String(r[9] || ''), user: String(r[10] || ''),
      thumbnailUrl: fileId ? ('https://drive.google.com/thumbnail?id=' + fileId + '&sz=w640') : ''
    };
  });
}

function buildBootstrap_(objects, transactions, lists, assignments, workdays, photos) {
  var txByObject = {};
  transactions.forEach(function (t) { if (t.objectId) { if (!txByObject[t.objectId]) txByObject[t.objectId] = []; txByObject[t.objectId].push(t); } });
  var assignmentByObject = {};
  assignments.forEach(function (a) { if (!assignmentByObject[a.objectId]) assignmentByObject[a.objectId] = []; assignmentByObject[a.objectId].push(a); });

  var enriched = objects.map(function (o) {
    var txs = txByObject[o.id] || [], received = 0, expenses = 0;
    txs.forEach(function (t) { if (t.type === 'Приход') received += Number(t.amount || 0); if (t.type === 'Расход') expenses += Number(t.amount || 0); });
    o.received = received; o.expenses = expenses; o.debt = Math.max(0, Number(o.contractAmount || 0) - received);
    o.projectedProfit = Number(o.contractAmount || 0) - expenses; o.cashResult = received - expenses; o.transactionsCount = txs.length;
    o.assignmentCount = (assignmentByObject[o.id] || []).length;
    o.photoCount = photos.filter(function (p) { return p.objectId === o.id; }).length;
    return o;
  });

  enriched.sort(function (a, b) { return String(b.updatedAt || '').localeCompare(String(a.updatedAt || '')); });
  transactions.sort(function (a, b) { var d = String(b.date || '').localeCompare(String(a.date || '')); return d !== 0 ? d : String(b.createdAt || '').localeCompare(String(a.createdAt || '')); });
  assignments.sort(function (a, b) { return String(a.startDate || '').localeCompare(String(b.startDate || '')); });
  workdays.sort(function (a, b) { var d = String(a.date || '').localeCompare(String(b.date || '')); return d !== 0 ? d : Number(a.dayNumber || 0) - Number(b.dayNumber || 0); });
  photos.sort(function (a, b) { return String(b.createdAt || '').localeCompare(String(a.createdAt || '')); });

  var totals = { contracts: 0, received: 0, expenses: 0, debt: 0, projectedProfit: 0, cashResult: 0, activeObjects: 0, completedObjects: 0 };
  enriched.forEach(function (o) {
    totals.contracts += Number(o.contractAmount || 0); totals.received += Number(o.received || 0); totals.expenses += Number(o.expenses || 0);
    totals.debt += Number(o.debt || 0); totals.projectedProfit += Number(o.projectedProfit || 0); totals.cashResult += Number(o.cashResult || 0);
    if (['Монтаж завершён', 'Закрыт', 'Отказ'].indexOf(o.status) === -1) totals.activeObjects++;
    if (['Монтаж завершён', 'Закрыт'].indexOf(o.status) !== -1) totals.completedObjects++;
  });
  transactions.forEach(function (t) { if (t.type === 'Расход' && !t.objectId) { totals.expenses += Number(t.amount || 0); totals.projectedProfit -= Number(t.amount || 0); totals.cashResult -= Number(t.amount || 0); } });

  var today = Utilities.formatDate(new Date(), TIMEZONE, 'yyyy-MM-dd');
  var engineerTotals = { assignments: assignments.length, activeAssignments: 0, todayDays: 0, overdueDays: 0, completedDays: 0, photos: photos.length, crewExpenses: 0 };
  assignments.forEach(function (a) { if (a.status !== 'Завершено' && a.status !== 'Отменено') engineerTotals.activeAssignments++; });
  workdays.forEach(function (d) { if (d.date === today) engineerTotals.todayDays++; if (d.date && d.date < today && d.status !== 'Завершён') engineerTotals.overdueDays++; if (d.status === 'Завершён') engineerTotals.completedDays++; });
  transactions.forEach(function (t) { if (t.type === 'Расход' && t.source === 'Монтажник') engineerTotals.crewExpenses += Number(t.amount || 0); });

  return {
    ok: true, version: APP_VERSION, generatedAt: new Date().toISOString(), objects: enriched, transactions: transactions,
    lists: lists, assignments: assignments, workdays: workdays, photos: photos, totals: totals, engineerTotals: engineerTotals
  };
}

function upsertWorkDays_(ss, assignmentId, assignmentPayload, days, plannedDays) {
  var sh = ss.getSheetByName(SHEET_WORKDAYS);
  var existing = {};
  if (sh.getLastRow() > 1) {
    var rows = sh.getRange(2, 1, sh.getLastRow() - 1, WORKDAY_HEADERS.length).getValues();
    rows.forEach(function (r, i) {
      if (String(r[3]) === String(assignmentId)) existing[Number(r[6] || 0)] = { row: i + 2, values: r };
    });
  }

  for (var n = 1; n <= plannedDays; n++) {
    var d = days[n - 1] || {};
    var prev = existing[n];
    var now = new Date();
    var dayDate = cleanText_(d.date) || addDaysIso_(cleanText_(assignmentPayload.startDate), n - 1);
    var tasks = Array.isArray(d.tasks) ? d.tasks : lines_(d.tasks);
    var requiredPhotos = Array.isArray(d.requiredPhotos) ? d.requiredPhotos : listText_(d.requiredPhotos);
    if (!requiredPhotos.length) requiredPhotos = ['До работ', 'В процессе', 'После работ'];

    var values = [
      prev ? String(prev.values[0]) : makeId_('DAY'),
      prev ? prev.values[1] : now,
      now,
      assignmentId,
      cleanText_(assignmentPayload.objectId),
      cleanText_(assignmentPayload.team),
      n,
      toDateOrBlank_(dayDate),
      cleanText_(d.title) || ('День ' + n),
      tasks.join('\n'),
      cleanText_(d.result),
      requiredPhotos.join(', '),
      prev ? prev.values[12] : '[]',
      prev ? prev.values[13] : '',
      prev ? prev.values[14] : '',
      prev ? prev.values[15] : '',
      prev ? (cleanText_(prev.values[16]) || 'Запланирован') : 'Запланирован',
      prev ? Number(prev.values[17] || 0) : 0,
      prev ? Number(prev.values[18] || 0) : 0,
      prev ? Number(prev.values[19] || 0) : 0
    ];

    if (prev) sh.getRange(prev.row, 1, 1, WORKDAY_HEADERS.length).setValues([values]);
    else { sh.appendRow(values); prev = { row: sh.getLastRow() }; }
    formatWorkDayRow_(sh, prev.row);
  }
}

function syncAssignmentAndObjectStatus_(ss, assignmentId, objectId) {
  var workdays = readWorkDays_(ss).filter(function (d) { return d.assignmentId === assignmentId; });
  var allDone = workdays.length > 0 && workdays.every(function (d) { return d.status === 'Завершён'; });
  var anyStarted = workdays.some(function (d) { return d.status === 'В работе' || d.status === 'Завершён'; });
  var assignmentStatus = allDone ? 'Завершено' : (anyStarted ? 'В работе' : 'Запланировано');

  var aSh = ss.getSheetByName(SHEET_ASSIGNMENTS), aRow = findRowById_(aSh, assignmentId);
  if (aRow) { aSh.getRange(aRow, 3).setValue(new Date()); aSh.getRange(aRow, 14).setValue(assignmentStatus); }

  var oSh = ss.getSheetByName(SHEET_OBJECTS), oRow = findRowById_(oSh, objectId);
  if (oRow) {
    oSh.getRange(oRow, 3).setValue(new Date());
    if (allDone) oSh.getRange(oRow, 11).setValue('Монтаж завершён');
    else if (anyStarted) oSh.getRange(oRow, 11).setValue('В работе');
  }
}

function ensurePhotoRoot_() {
  var props = PropertiesService.getScriptProperties();
  var id = props.getProperty(PROP_PHOTO_FOLDER_ID);
  if (id) {
    try { return DriveApp.getFolderById(id); } catch (ignored) {}
  }
  var folders = DriveApp.getFoldersByName('Тёплая Компания — Фото монтажей');
  var folder = folders.hasNext() ? folders.next() : DriveApp.createFolder('Тёплая Компания — Фото монтажей');
  props.setProperty(PROP_PHOTO_FOLDER_ID, folder.getId());
  return folder;
}

function ensureChildFolder_(parent, name) {
  name = cleanFileName_(name || 'Без объекта');
  var it = parent.getFoldersByName(name);
  return it.hasNext() ? it.next() : parent.createFolder(name);
}

function parseDataUrl_(dataUrl) {
  var m = /^data:([^;]+);base64,(.+)$/.exec(String(dataUrl || ''));
  if (!m) throw new Error('Неверный формат фотографии.');
  return { mime: m[1], bytes: Utilities.base64Decode(m[2]) };
}

function mimeExtension_(mime) {
  mime = String(mime || '').toLowerCase();
  if (mime.indexOf('png') >= 0) return '.png';
  if (mime.indexOf('webp') >= 0) return '.webp';
  if (mime.indexOf('heic') >= 0 || mime.indexOf('heif') >= 0) return '.heic';
  return '.jpg';
}

function validateObjectPayload_(p) {
  if (!p) throw new Error('Нет данных объекта.');
  if (!cleanText_(p.clientName)) throw new Error('Укажите имя клиента.');
  if (!cleanText_(p.workType)) throw new Error('Выберите вид работ.');
  if (toNumber_(p.contractAmount) < 0) throw new Error('Сумма договора не может быть отрицательной.');
}

function validateTransactionPayload_(p) {
  if (!p) throw new Error('Нет данных операции.');
  var type = cleanText_(p.type);
  if (['Приход', 'Расход'].indexOf(type) === -1) throw new Error('Выберите тип операции.');
  if (toNumber_(p.amount) <= 0) throw new Error('Сумма должна быть больше нуля.');
  if (type === 'Расход' && !cleanText_(p.category)) throw new Error('Выберите статью расхода.');
}

function validateAssignmentPayload_(p) {
  if (!p) throw new Error('Нет данных задания.');
  if (!cleanText_(p.objectId)) throw new Error('Выберите объект.');
  if (!cleanText_(p.team)) throw new Error('Выберите бригаду.');
  if (!cleanText_(p.startDate)) throw new Error('Укажите дату начала работ.');
  if (!cleanText_(p.workSummary)) throw new Error('Опишите общее задание для бригады.');
  if (Number(p.plannedDays || 0) < 1 || Number(p.plannedDays || 0) > 30) throw new Error('Количество дней должно быть от 1 до 30.');
}

function findRowById_(sh, id) {
  if (!sh || !id || sh.getLastRow() <= 1) return 0;
  var vals = sh.getRange(2, 1, sh.getLastRow() - 1, 1).getDisplayValues();
  for (var i = 0; i < vals.length; i++) if (String(vals[i][0]) === String(id)) return i + 2;
  return 0;
}

function writeRow_(sh, row, values, columns) {
  if (row) sh.getRange(row, 1, 1, columns).setValues([values]);
  else sh.appendRow(values);
}

function deleteRowsByColumn_(sh, col, value) {
  if (!sh || sh.getLastRow() <= 1) return;
  var vals = sh.getRange(2, col, sh.getLastRow() - 1, 1).getDisplayValues();
  for (var i = vals.length - 1; i >= 0; i--) if (String(vals[i][0]) === String(value)) sh.deleteRow(i + 2);
}

function formatObjectRow_(sh, row) { sh.getRange(row, 2, 1, 2).setNumberFormat('dd.MM.yyyy HH:mm'); sh.getRange(row, 8).setNumberFormat('#,##0.00 ₽'); sh.getRange(row, 9, 1, 2).setNumberFormat('dd.MM.yyyy'); }
function formatTransactionRow_(sh, row) { sh.getRange(row, 2).setNumberFormat('dd.MM.yyyy HH:mm'); sh.getRange(row, 4).setNumberFormat('dd.MM.yyyy'); sh.getRange(row, 8).setNumberFormat('#,##0.00 ₽'); }
function formatAssignmentRow_(sh, row) { sh.getRange(row, 2, 1, 2).setNumberFormat('dd.MM.yyyy HH:mm'); sh.getRange(row, 7).setNumberFormat('dd.MM.yyyy'); }
function formatWorkDayRow_(sh, row) { sh.getRange(row, 2, 1, 2).setNumberFormat('dd.MM.yyyy HH:mm'); sh.getRange(row, 8).setNumberFormat('dd.MM.yyyy'); sh.getRange(row, 15, 1, 2).setNumberFormat('dd.MM.yyyy HH:mm'); }
function formatPhotoRow_(sh, row) { sh.getRange(row, 2).setNumberFormat('dd.MM.yyyy HH:mm'); }

function cleanText_(v) { return String(v == null ? '' : v).trim().replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, ''); }
function cleanPhone_(v) { return cleanText_(v).slice(0, 40); }
function cleanFileName_(v) { return cleanText_(v).replace(/[\\/:*?"<>|#%{}]/g, '_').slice(0, 140) || 'file'; }
function toNumber_(v) { if (typeof v === 'number') return isFinite(v) ? v : 0; var s = String(v == null ? '' : v).replace(/\s/g, '').replace(',', '.').replace(/[^0-9.\-]/g, ''); var n = parseFloat(s); return isFinite(n) ? n : 0; }
function toDateOrBlank_(v) { if (!v) return ''; if (Object.prototype.toString.call(v) === '[object Date]') return v; var s = String(v), parts = s.split('-'); if (parts.length === 3) return new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2])); var d = new Date(s); return isNaN(d.getTime()) ? '' : d; }
function dateIso_(v) { if (!v) return ''; var d = v instanceof Date ? v : new Date(v); if (isNaN(d.getTime())) return ''; return Utilities.formatDate(d, TIMEZONE, "yyyy-MM-dd'T'HH:mm:ss"); }
function dateOnly_(v) { if (!v) return ''; var d = v instanceof Date ? v : new Date(v); if (isNaN(d.getTime())) return ''; return Utilities.formatDate(d, TIMEZONE, 'yyyy-MM-dd'); }
function lines_(v) { if (Array.isArray(v)) return v.filter(function (x) { return cleanText_(x); }).map(cleanText_); return String(v == null ? '' : v).split(/\r?\n/).map(cleanText_).filter(function (x) { return !!x; }); }
function listText_(v) { if (Array.isArray(v)) return v.filter(function (x) { return cleanText_(x); }).map(cleanText_); return String(v == null ? '' : v).split(/[,;\n]/).map(cleanText_).filter(function (x) { return !!x; }); }
function jsonArray_(v) { if (Array.isArray(v)) return v; try { var a = JSON.parse(String(v || '[]')); return Array.isArray(a) ? a : []; } catch (e) { return []; } }
function addDaysIso_(iso, add) { var d = toDateOrBlank_(iso); if (!d) d = new Date(); d.setDate(d.getDate() + Number(add || 0)); return Utilities.formatDate(d, TIMEZONE, 'yyyy-MM-dd'); }
function makeId_(prefix) { return prefix + '-' + Utilities.formatDate(new Date(), TIMEZONE, 'yyyyMMdd-HHmmss') + '-' + Utilities.getUuid().slice(0, 6).toUpperCase(); }

function withLock_(fn) {
  var lock = LockService.getScriptLock(); lock.waitLock(15000);
  try { return fn(); } finally { lock.releaseLock(); }
}
