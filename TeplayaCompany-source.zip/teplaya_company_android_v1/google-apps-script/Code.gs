/**
 * Тёплая Компания — мобильное веб-приложение v1.0
 * Google Apps Script + Google Sheets
 *
 * Установка:
 * 1) Создайте Google Таблицу.
 * 2) Расширения -> Apps Script.
 * 3) Вставьте этот файл как Code.gs, а Index.html — как HTML-файл Index.
 * 4) Запустите setupApp() один раз и выдайте разрешения.
 * 5) Развернуть -> Новое развертывание -> Веб-приложение.
 */

var APP_VERSION = '1.0.0';
var PROP_SPREADSHEET_ID = 'TK_SPREADSHEET_ID';
var SHEET_OBJECTS = 'Объекты';
var SHEET_TX = 'Операции';
var SHEET_LISTS = 'Списки';
var TIMEZONE = 'Europe/Moscow';

var OBJECT_HEADERS = [
  'ID', 'Создан', 'Изменен', 'Клиент', 'Телефон', 'Адрес', 'Вид работ',
  'Сумма договора', 'Дата замера', 'Дата монтажа', 'Статус', 'Бригада',
  'Ответственный', 'Комментарий'
];

var TX_HEADERS = [
  'ID', 'Создан', 'ID объекта', 'Дата', 'Тип', 'Вид расхода', 'Статья',
  'Сумма', 'Комментарий', 'Пользователь'
];

var LIST_HEADERS = ['Тип', 'Значение', 'Сортировка', 'Активно'];

function doGet() {
  return HtmlService.createTemplateFromFile('Index')
    .evaluate()
    .setTitle('Тёплая Компания')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no');
}

function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

/**
 * Одноразовая настройка базы. Запускать вручную из редактора Apps Script.
 */
function setupApp() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  if (!ss) {
    throw new Error('Откройте Apps Script из нужной Google Таблицы: Расширения → Apps Script.');
  }

  PropertiesService.getScriptProperties().setProperty(PROP_SPREADSHEET_ID, ss.getId());
  ss.setSpreadsheetTimeZone(TIMEZONE);

  var objects = ensureSheet_(ss, SHEET_OBJECTS, OBJECT_HEADERS);
  var tx = ensureSheet_(ss, SHEET_TX, TX_HEADERS);
  var lists = ensureSheet_(ss, SHEET_LISTS, LIST_HEADERS);

  styleSheet_(objects, OBJECT_HEADERS.length);
  styleSheet_(tx, TX_HEADERS.length);
  styleSheet_(lists, LIST_HEADERS.length);

  seedLists_(lists);
  applyFormats_(objects, tx, lists);
  applyValidations_(objects);

  return {
    ok: true,
    message: 'Готово. База приложения создана.',
    spreadsheetId: ss.getId(),
    version: APP_VERSION
  };
}

function apiBootstrap() {
  var ss = getSpreadsheet_();
  ensureAppStructure_(ss);

  var objects = readObjects_(ss);
  var transactions = readTransactions_(ss);
  var lists = readLists_(ss);

  return buildBootstrap_(objects, transactions, lists);
}

function apiSaveObject(payload) {
  return withLock_(function () {
    validateObjectPayload_(payload);
    var ss = getSpreadsheet_();
    ensureAppStructure_(ss);
    var sh = ss.getSheetByName(SHEET_OBJECTS);
    var now = new Date();
    var id = cleanText_(payload.id) || makeId_('OBJ');
    var row = findRowById_(sh, id);

    var values = [
      id,
      row ? sh.getRange(row, 2).getValue() : now,
      now,
      cleanText_(payload.clientName),
      cleanPhone_(payload.phone),
      cleanText_(payload.address),
      cleanText_(payload.workType),
      toNumber_(payload.contractAmount),
      toDateOrBlank_(payload.measureDate),
      toDateOrBlank_(payload.installDate),
      cleanText_(payload.status) || 'Новая заявка',
      cleanText_(payload.team),
      cleanText_(payload.responsible),
      cleanText_(payload.comment)
    ];

    if (row) {
      sh.getRange(row, 1, 1, OBJECT_HEADERS.length).setValues([values]);
    } else {
      sh.appendRow(values);
      row = sh.getLastRow();
    }

    formatObjectRow_(sh, row);
    return apiBootstrap();
  });
}

function apiDeleteObject(id) {
  return withLock_(function () {
    id = cleanText_(id);
    if (!id) throw new Error('Не передан ID объекта.');

    var ss = getSpreadsheet_();
    var objects = ss.getSheetByName(SHEET_OBJECTS);
    var tx = ss.getSheetByName(SHEET_TX);

    var row = findRowById_(objects, id);
    if (row) objects.deleteRow(row);

    if (tx.getLastRow() > 1) {
      var data = tx.getRange(2, 1, tx.getLastRow() - 1, TX_HEADERS.length).getValues();
      for (var i = data.length - 1; i >= 0; i--) {
        if (String(data[i][2]) === id) tx.deleteRow(i + 2);
      }
    }
    return apiBootstrap();
  });
}

function apiUpdateStatus(id, status) {
  return withLock_(function () {
    var ss = getSpreadsheet_();
    var sh = ss.getSheetByName(SHEET_OBJECTS);
    var row = findRowById_(sh, cleanText_(id));
    if (!row) throw new Error('Объект не найден.');
    sh.getRange(row, 11).setValue(cleanText_(status));
    sh.getRange(row, 3).setValue(new Date());
    return apiBootstrap();
  });
}

function apiAddTransaction(payload) {
  return withLock_(function () {
    validateTransactionPayload_(payload);
    var ss = getSpreadsheet_();
    ensureAppStructure_(ss);
    var sh = ss.getSheetByName(SHEET_TX);
    var now = new Date();
    var id = cleanText_(payload.id) || makeId_('TX');
    var row = findRowById_(sh, id);

    var type = cleanText_(payload.type);
    var expenseKind = type === 'Расход' ? (cleanText_(payload.expenseKind) || 'Расход по объекту') : '';
    var objectId = cleanText_(payload.objectId);
    if (type === 'Приход' && !objectId) throw new Error('Для прихода выберите объект.');
    if (type === 'Расход' && expenseKind === 'Расход по объекту' && !objectId) {
      throw new Error('Для расхода по объекту выберите объект.');
    }
    if (expenseKind === 'Прочий расход по статье') objectId = '';

    var values = [
      id,
      row ? sh.getRange(row, 2).getValue() : now,
      objectId,
      toDateOrBlank_(payload.date) || now,
      type,
      expenseKind,
      cleanText_(payload.category),
      toNumber_(payload.amount),
      cleanText_(payload.comment),
      cleanText_(payload.user)
    ];

    if (row) {
      sh.getRange(row, 1, 1, TX_HEADERS.length).setValues([values]);
    } else {
      sh.appendRow(values);
      row = sh.getLastRow();
    }
    formatTransactionRow_(sh, row);
    return apiBootstrap();
  });
}

function apiDeleteTransaction(id) {
  return withLock_(function () {
    var ss = getSpreadsheet_();
    var sh = ss.getSheetByName(SHEET_TX);
    var row = findRowById_(sh, cleanText_(id));
    if (row) sh.deleteRow(row);
    return apiBootstrap();
  });
}

function apiSaveListItem(payload) {
  return withLock_(function () {
    var type = cleanText_(payload.type);
    var value = cleanText_(payload.value);
    if (!type || !value) throw new Error('Укажите тип и значение.');
    var ss = getSpreadsheet_();
    var sh = ss.getSheetByName(SHEET_LISTS);
    var last = sh.getLastRow();
    var sort = last;
    sh.appendRow([type, value, sort, true]);
    return apiBootstrap();
  });
}

function getSpreadsheet_() {
  var id = PropertiesService.getScriptProperties().getProperty(PROP_SPREADSHEET_ID);
  if (!id) {
    throw new Error('Приложение ещё не настроено. Запустите функцию setupApp() один раз из редактора Apps Script.');
  }
  return SpreadsheetApp.openById(id);
}

function ensureAppStructure_(ss) {
  var objects = ensureSheet_(ss, SHEET_OBJECTS, OBJECT_HEADERS);
  var tx = ensureSheet_(ss, SHEET_TX, TX_HEADERS);
  var lists = ensureSheet_(ss, SHEET_LISTS, LIST_HEADERS);
  if (lists.getLastRow() <= 1) seedLists_(lists);
  applyFormats_(objects, tx, lists);
}

function ensureSheet_(ss, name, headers) {
  var sh = ss.getSheetByName(name);
  if (!sh) sh = ss.insertSheet(name);
  if (sh.getLastRow() === 0) {
    sh.getRange(1, 1, 1, headers.length).setValues([headers]);
  } else {
    var current = sh.getRange(1, 1, 1, headers.length).getDisplayValues()[0];
    var mismatch = false;
    for (var i = 0; i < headers.length; i++) {
      if (current[i] !== headers[i]) { mismatch = true; break; }
    }
    if (mismatch && sh.getLastRow() === 1) {
      sh.getRange(1, 1, 1, headers.length).setValues([headers]);
    }
  }
  return sh;
}

function styleSheet_(sh, columns) {
  sh.setFrozenRows(1);
  sh.getRange(1, 1, 1, columns)
    .setFontWeight('bold')
    .setBackground('#153e75')
    .setFontColor('#ffffff')
    .setHorizontalAlignment('center');
  sh.setRowHeight(1, 34);
  sh.getDataRange().setVerticalAlignment('middle');
}

function applyFormats_(objects, tx, lists) {
  styleSheet_(objects, OBJECT_HEADERS.length);
  styleSheet_(tx, TX_HEADERS.length);
  styleSheet_(lists, LIST_HEADERS.length);

  objects.setColumnWidths(1, OBJECT_HEADERS.length, 130);
  objects.setColumnWidth(4, 190);
  objects.setColumnWidth(6, 260);
  objects.setColumnWidth(14, 300);
  objects.getRange('B:C').setNumberFormat('dd.MM.yyyy HH:mm');
  objects.getRange('H:H').setNumberFormat('#,##0.00 ₽');
  objects.getRange('I:J').setNumberFormat('dd.MM.yyyy');

  tx.setColumnWidths(1, TX_HEADERS.length, 130);
  tx.setColumnWidth(9, 280);
  tx.getRange('B:B').setNumberFormat('dd.MM.yyyy HH:mm');
  tx.getRange('D:D').setNumberFormat('dd.MM.yyyy');
  tx.getRange('H:H').setNumberFormat('#,##0.00 ₽');
}

function applyValidations_(objects) {
  var lists = readLists_(getSpreadsheet_());
  var workTypes = lists.workTypes || [];
  var statuses = lists.statuses || [];
  var teams = lists.teams || [];
  var responsibles = lists.responsibles || [];

  if (workTypes.length) objects.getRange('G2:G').setDataValidation(SpreadsheetApp.newDataValidation().requireValueInList(workTypes, true).build());
  if (statuses.length) objects.getRange('K2:K').setDataValidation(SpreadsheetApp.newDataValidation().requireValueInList(statuses, true).build());
  if (teams.length) objects.getRange('L2:L').setDataValidation(SpreadsheetApp.newDataValidation().requireValueInList(teams, true).build());
  if (responsibles.length) objects.getRange('M2:M').setDataValidation(SpreadsheetApp.newDataValidation().requireValueInList(responsibles, true).build());
}

function seedLists_(sh) {
  if (sh.getLastRow() > 1) return;
  var rows = [];
  addListRows_(rows, 'status', [
    'Новая заявка', 'Замер назначен', 'Замер проведён', 'КП отправлено',
    'Договор', 'Запланирован монтаж', 'В работе', 'Монтаж завершён', 'Закрыт', 'Отказ'
  ]);
  addListRows_(rows, 'workType', [
    'Утепление', 'Утепление пола', 'Утепление чердака', 'Утепление мансарды',
    'Утепление скатов', 'Утепление стен', 'Фасадные работы', 'Кровельные работы',
    'Внутренняя отделка'
  ]);
  addListRows_(rows, 'team', ['Бригада 1', 'Бригада 2', 'Бригада 3', 'Бригада 4']);
  addListRows_(rows, 'responsible', ['Игорь', 'Константин', 'Инженер']);
  addListRows_(rows, 'expenseCategory', [
    'Материалы', 'Монтажные работы', 'Зарплата', 'Доставка', 'Топливо', 'Аренда',
    'Реклама', 'Инструмент', 'Связь', 'Кредиты', 'Налоги', 'Прочее'
  ]);
  sh.getRange(2, 1, rows.length, LIST_HEADERS.length).setValues(rows);
}

function addListRows_(target, type, values) {
  for (var i = 0; i < values.length; i++) {
    target.push([type, values[i], i + 1, true]);
  }
}

function readObjects_(ss) {
  var sh = ss.getSheetByName(SHEET_OBJECTS);
  if (!sh || sh.getLastRow() <= 1) return [];
  var rows = sh.getRange(2, 1, sh.getLastRow() - 1, OBJECT_HEADERS.length).getValues();
  var out = [];
  rows.forEach(function (r) {
    if (!r[0]) return;
    out.push({
      id: String(r[0]),
      createdAt: dateIso_(r[1]),
      updatedAt: dateIso_(r[2]),
      clientName: String(r[3] || ''),
      phone: String(r[4] || ''),
      address: String(r[5] || ''),
      workType: String(r[6] || ''),
      contractAmount: Number(r[7] || 0),
      measureDate: dateOnly_(r[8]),
      installDate: dateOnly_(r[9]),
      status: String(r[10] || ''),
      team: String(r[11] || ''),
      responsible: String(r[12] || ''),
      comment: String(r[13] || '')
    });
  });
  return out;
}

function readTransactions_(ss) {
  var sh = ss.getSheetByName(SHEET_TX);
  if (!sh || sh.getLastRow() <= 1) return [];
  var rows = sh.getRange(2, 1, sh.getLastRow() - 1, TX_HEADERS.length).getValues();
  var out = [];
  rows.forEach(function (r) {
    if (!r[0]) return;
    out.push({
      id: String(r[0]),
      createdAt: dateIso_(r[1]),
      objectId: String(r[2] || ''),
      date: dateOnly_(r[3]),
      type: String(r[4] || ''),
      expenseKind: String(r[5] || ''),
      category: String(r[6] || ''),
      amount: Number(r[7] || 0),
      comment: String(r[8] || ''),
      user: String(r[9] || '')
    });
  });
  return out;
}

function readLists_(ss) {
  var sh = ss.getSheetByName(SHEET_LISTS);
  var out = { statuses: [], workTypes: [], teams: [], responsibles: [], expenseCategories: [] };
  if (!sh || sh.getLastRow() <= 1) return out;
  var rows = sh.getRange(2, 1, sh.getLastRow() - 1, LIST_HEADERS.length).getValues();
  rows.sort(function (a, b) { return Number(a[2] || 0) - Number(b[2] || 0); });
  rows.forEach(function (r) {
    var active = r[3];
    if (active === false || String(active).toLowerCase() === 'false') return;
    var type = String(r[0] || '');
    var value = String(r[1] || '');
    if (!value) return;
    if (type === 'status') out.statuses.push(value);
    if (type === 'workType') out.workTypes.push(value);
    if (type === 'team') out.teams.push(value);
    if (type === 'responsible') out.responsibles.push(value);
    if (type === 'expenseCategory') out.expenseCategories.push(value);
  });
  return out;
}

function buildBootstrap_(objects, transactions, lists) {
  var txByObject = {};
  transactions.forEach(function (t) {
    if (!t.objectId) return;
    if (!txByObject[t.objectId]) txByObject[t.objectId] = [];
    txByObject[t.objectId].push(t);
  });

  var enriched = objects.map(function (o) {
    var txs = txByObject[o.id] || [];
    var received = 0;
    var expenses = 0;
    txs.forEach(function (t) {
      if (t.type === 'Приход') received += Number(t.amount || 0);
      if (t.type === 'Расход') expenses += Number(t.amount || 0);
    });
    o.received = received;
    o.expenses = expenses;
    o.debt = Math.max(0, Number(o.contractAmount || 0) - received);
    o.projectedProfit = Number(o.contractAmount || 0) - expenses;
    o.cashResult = received - expenses;
    o.transactionsCount = txs.length;
    return o;
  });

  enriched.sort(function (a, b) {
    return String(b.updatedAt || '').localeCompare(String(a.updatedAt || ''));
  });
  transactions.sort(function (a, b) {
    var d = String(b.date || '').localeCompare(String(a.date || ''));
    return d !== 0 ? d : String(b.createdAt || '').localeCompare(String(a.createdAt || ''));
  });

  var totals = {
    contracts: 0,
    received: 0,
    expenses: 0,
    debt: 0,
    projectedProfit: 0,
    cashResult: 0,
    activeObjects: 0,
    completedObjects: 0
  };

  enriched.forEach(function (o) {
    totals.contracts += Number(o.contractAmount || 0);
    totals.received += Number(o.received || 0);
    totals.expenses += Number(o.expenses || 0);
    totals.debt += Number(o.debt || 0);
    totals.projectedProfit += Number(o.projectedProfit || 0);
    totals.cashResult += Number(o.cashResult || 0);
    if (['Монтаж завершён', 'Закрыт', 'Отказ'].indexOf(o.status) === -1) totals.activeObjects++;
    if (['Монтаж завершён', 'Закрыт'].indexOf(o.status) !== -1) totals.completedObjects++;
  });

  // Добавляем прочие расходы без объекта в общие расходы и денежный результат.
  transactions.forEach(function (t) {
    if (t.type === 'Расход' && !t.objectId) {
      totals.expenses += Number(t.amount || 0);
      totals.projectedProfit -= Number(t.amount || 0);
      totals.cashResult -= Number(t.amount || 0);
    }
  });

  return {
    ok: true,
    version: APP_VERSION,
    generatedAt: new Date().toISOString(),
    objects: enriched,
    transactions: transactions,
    lists: lists,
    totals: totals
  };
}

function validateObjectPayload_(p) {
  if (!p) throw new Error('Нет данных объекта.');
  if (!cleanText_(p.clientName)) throw new Error('Укажите имя клиента.');
  if (!cleanText_(p.workType)) throw new Error('Выберите вид работ.');
  if (toNumber_(p.contractAmount) < 0) throw new Error('Сумма договора не может быть отрицательной.');
}

function validateTransactionPayload_(p) {
  if (!p) throw new Error('Нет данных операции.');
  var type = cleanText_(p.type);
  if (['Приход', 'Расход'].indexOf(type) === -1) throw new Error('Выберите тип операции.');
  if (toNumber_(p.amount) <= 0) throw new Error('Сумма должна быть больше нуля.');
  if (type === 'Расход' && !cleanText_(p.category)) throw new Error('Выберите статью расхода.');
}

function findRowById_(sh, id) {
  if (!id || sh.getLastRow() <= 1) return 0;
  var vals = sh.getRange(2, 1, sh.getLastRow() - 1, 1).getDisplayValues();
  for (var i = 0; i < vals.length; i++) {
    if (String(vals[i][0]) === String(id)) return i + 2;
  }
  return 0;
}

function formatObjectRow_(sh, row) {
  sh.getRange(row, 2, 1, 2).setNumberFormat('dd.MM.yyyy HH:mm');
  sh.getRange(row, 8).setNumberFormat('#,##0.00 ₽');
  sh.getRange(row, 9, 1, 2).setNumberFormat('dd.MM.yyyy');
}

function formatTransactionRow_(sh, row) {
  sh.getRange(row, 2).setNumberFormat('dd.MM.yyyy HH:mm');
  sh.getRange(row, 4).setNumberFormat('dd.MM.yyyy');
  sh.getRange(row, 8).setNumberFormat('#,##0.00 ₽');
}

function cleanText_(v) {
  return String(v == null ? '' : v).trim().replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '');
}

function cleanPhone_(v) {
  return cleanText_(v).slice(0, 40);
}

function toNumber_(v) {
  if (typeof v === 'number') return isFinite(v) ? v : 0;
  var s = String(v == null ? '' : v).replace(/\s/g, '').replace(',', '.').replace(/[^0-9.\-]/g, '');
  var n = parseFloat(s);
  return isFinite(n) ? n : 0;
}

function toDateOrBlank_(v) {
  if (!v) return '';
  if (Object.prototype.toString.call(v) === '[object Date]') return v;
  var s = String(v);
  var parts = s.split('-');
  if (parts.length === 3) return new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
  var d = new Date(s);
  return isNaN(d.getTime()) ? '' : d;
}

function dateIso_(v) {
  if (!v) return '';
  var d = v instanceof Date ? v : new Date(v);
  if (isNaN(d.getTime())) return '';
  return Utilities.formatDate(d, TIMEZONE, "yyyy-MM-dd'T'HH:mm:ss");
}

function dateOnly_(v) {
  if (!v) return '';
  var d = v instanceof Date ? v : new Date(v);
  if (isNaN(d.getTime())) return '';
  return Utilities.formatDate(d, TIMEZONE, 'yyyy-MM-dd');
}

function makeId_(prefix) {
  return prefix + '-' + Utilities.formatDate(new Date(), TIMEZONE, 'yyyyMMdd-HHmmss') + '-' + Utilities.getUuid().slice(0, 6).toUpperCase();
}

function withLock_(fn) {
  var lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    return fn();
  } finally {
    lock.releaseLock();
  }
}
