package ru.teplaya.company;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.View;
import android.view.Window;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String PREFS = "tk_prefs";
    private static final String KEY_URL = "apps_script_url";
    private static final String LOCAL_URL = "file:///android_asset/index.html";
    private static final int FILE_CHOOSER_REQUEST = 9042;
    private static final int LOCATION_PERMISSION_REQUEST = 9043;
    private static final int NOTIFICATION_PERMISSION_REQUEST = 9044;
    public static final String CHANNEL_ID = "tk_workday";

    private WebView webView;
    private SharedPreferences prefs;
    private ValueCallback<Uri[]> filePathCallback;
    private Uri cameraPhotoUri;
    private GeolocationPermissions.Callback geoCallback;
    private String geoOrigin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(38,118,114));
        window.setNavigationBarColor(Color.WHITE);
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        createNotificationChannel();
        requestNotificationPermissionIfNeeded();
        webView = new WebView(this);
        setContentView(webView);
        configureWebView();
        loadConfiguredApp();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Рабочий день монтажника",
                NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Напоминания о начале дня, фото, расходах и закрытии рабочего дня");
            nm.createNotificationChannel(channel);
        }
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION_REQUEST);
        }
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setGeolocationEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setBackgroundColor(Color.rgb(247,245,239));
        webView.addJavascriptInterface(new NativeBridge(), "NativeApp");

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent contentIntent;
                try { contentIntent = params.createIntent(); }
                catch (Exception e) {
                    contentIntent = new Intent(Intent.ACTION_GET_CONTENT);
                    contentIntent.addCategory(Intent.CATEGORY_OPENABLE);
                    contentIntent.setType("image/*");
                }
                Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if (cameraIntent.resolveActivity(getPackageManager()) != null) {
                    try {
                        File photoFile = createImageFile();
                        cameraPhotoUri = FileProvider.getUriForFile(MainActivity.this, getPackageName()+".fileprovider", photoFile);
                        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, cameraPhotoUri);
                        cameraIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } catch (IOException e) { cameraIntent = null; cameraPhotoUri = null; }
                } else cameraIntent = null;
                Intent chooser = Intent.createChooser(contentIntent, "Фото для объекта");
                if (cameraIntent != null) chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cameraIntent});
                try { startActivityForResult(chooser, FILE_CHOOSER_REQUEST); return true; }
                catch (Exception e) { filePathCallback = null; Toast.makeText(MainActivity.this,"Не удалось открыть выбор фотографии",Toast.LENGTH_SHORT).show(); return false; }
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    callback.invoke(origin,true,false); return;
                }
                geoCallback=callback; geoOrigin=origin;
                ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},LOCATION_PERMISSION_REQUEST);
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri=request.getUrl(); String scheme=uri.getScheme();
                if ("tel".equalsIgnoreCase(scheme)||"mailto".equalsIgnoreCase(scheme)) { try{startActivity(new Intent(Intent.ACTION_VIEW,uri));}catch(Exception ignored){} return true; }
                if ("https".equalsIgnoreCase(scheme)&&uri.getHost()!=null&&uri.getHost().contains("drive.google.com")) { try{startActivity(new Intent(Intent.ACTION_VIEW,uri));}catch(Exception ignored){} return true; }
                return false;
            }
        });

        webView.setOnLongClickListener(v->{showSettingsDialog();return true;});
    }

    private File createImageFile() throws IOException {
        String stamp=new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date());
        return File.createTempFile("TK_"+stamp+"_",".jpg",getExternalFilesDir(Environment.DIRECTORY_PICTURES));
    }

    @Override
    protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode!=FILE_CHOOSER_REQUEST||filePathCallback==null)return;
        Uri[] results=null;
        if(resultCode==RESULT_OK){if(data==null||data.getData()==null){if(cameraPhotoUri!=null)results=new Uri[]{cameraPhotoUri};}else results=WebChromeClient.FileChooserParams.parseResult(resultCode,data);}
        filePathCallback.onReceiveValue(results);filePathCallback=null;cameraPhotoUri=null;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==LOCATION_PERMISSION_REQUEST&&geoCallback!=null){boolean granted=false;for(int r:grantResults)if(r==PackageManager.PERMISSION_GRANTED){granted=true;break;}geoCallback.invoke(geoOrigin==null?"":geoOrigin,granted,false);geoCallback=null;geoOrigin=null;}
    }

    private void loadConfiguredApp(){
        String url=prefs.getString(KEY_URL,"").trim();
        if(isValidBackendUrl(url)) webView.loadUrl(url);
        else { webView.loadUrl(LOCAL_URL); Toast.makeText(this,"Демо v3. Нажмите ⚙, чтобы подключить Google Sheets.",Toast.LENGTH_LONG).show(); }
    }

    private boolean isValidBackendUrl(String url){if(url==null)return false;String u=url.trim().toLowerCase();return u.startsWith("https://")&&(u.contains("script.google.com/")||u.contains("script.googleusercontent.com/"));}

    private void showSettingsDialog(){
        runOnUiThread(()->{
            final EditText input=new EditText(MainActivity.this);input.setSingleLine(false);input.setMinLines(2);input.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI);input.setHint("https://script.google.com/macros/s/.../exec");input.setText(prefs.getString(KEY_URL,""));int pad=dp(18);input.setPadding(pad,pad,pad,pad);
            AlertDialog dialog=new AlertDialog.Builder(MainActivity.this)
                .setTitle("Подключение Google Sheets")
                .setMessage("Вставьте ссылку веб-приложения Google Apps Script (/exec). v3 подтянет справочники, бригады, участников, график, фото и начисления ЗП из этой таблицы.")
                .setView(input).setNegativeButton("Отмена",null)
                .setNeutralButton("Демо",(d,w)->{prefs.edit().remove(KEY_URL).apply();webView.loadUrl(LOCAL_URL);})
                .setPositiveButton("Подключить",null).create();
            dialog.setOnShowListener(d->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String url=input.getText().toString().trim();if(!isValidBackendUrl(url)){input.setError("Нужна HTTPS-ссылка Google Apps Script, заканчивающаяся на /exec");return;}prefs.edit().putString(KEY_URL,url).apply();dialog.dismiss();webView.loadUrl(url);Toast.makeText(MainActivity.this,"Google Sheets подключены",Toast.LENGTH_SHORT).show();}));dialog.show();
        });
    }

    private int dp(int value){return Math.round(value*getResources().getDisplayMetrics().density);}

    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
    @Override protected void onDestroy(){if(filePathCallback!=null){filePathCallback.onReceiveValue(null);filePathCallback=null;}if(geoCallback!=null){geoCallback.invoke(geoOrigin==null?"":geoOrigin,false,false);geoCallback=null;geoOrigin=null;}if(webView!=null){webView.destroy();webView=null;}super.onDestroy();}

    public class NativeBridge {
        @JavascriptInterface public void openSettings(){showSettingsDialog();}
        @JavascriptInterface public String getBackendUrl(){return prefs.getString(KEY_URL,"");}
        @JavascriptInterface public boolean isAndroidApp(){return true;}

        @JavascriptInterface
        public void scheduleReminder(String id,long whenMillis,String title,String body){
            if(whenMillis<=System.currentTimeMillis())return;
            Intent intent=new Intent(MainActivity.this,ReminderReceiver.class);
            intent.putExtra("title",title);intent.putExtra("body",body);intent.putExtra("notification_id",Math.abs(id.hashCode()));
            PendingIntent pi=PendingIntent.getBroadcast(MainActivity.this,Math.abs(id.hashCode()),intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,whenMillis,pi);
        }

        @JavascriptInterface
        public void cancelReminder(String id){
            Intent intent=new Intent(MainActivity.this,ReminderReceiver.class);
            PendingIntent pi=PendingIntent.getBroadcast(MainActivity.this,Math.abs(id.hashCode()),intent,PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE);
            if(pi!=null){AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);am.cancel(pi);pi.cancel();}
        }
    }
}
