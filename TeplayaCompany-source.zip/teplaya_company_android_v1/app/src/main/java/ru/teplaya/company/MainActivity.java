package ru.teplaya.company;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String PREFS = "tk_prefs";
    private static final String KEY_URL = "apps_script_url";
    private static final String LOCAL_URL = "file:///android_asset/index.html";

    private WebView webView;
    private SharedPreferences prefs;
    private boolean fallbackShown = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(18, 62, 100));
        window.setNavigationBarColor(Color.WHITE);

        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        webView = new WebView(this);
        setContentView(webView);
        configureWebView();
        loadConfiguredApp();
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setBackgroundColor(Color.rgb(244, 247, 251));
        webView.addJavascriptInterface(new NativeBridge(), "NativeApp");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("tel".equalsIgnoreCase(scheme) || "mailto".equalsIgnoreCase(scheme)) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) {}
                    return true;
                }
                if ("tkapp".equalsIgnoreCase(scheme)) {
                    if ("settings".equalsIgnoreCase(uri.getHost())) showSettingsDialog();
                    return true;
                }
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                injectNativeHooks();
            }
        });

        // Резервный способ открыть настройки: долгое нажатие по странице.
        webView.setOnLongClickListener(v -> {
            showSettingsDialog();
            return true;
        });
    }

    private void injectNativeHooks() {
        String script = "(function(){" +
            "try{" +
            "var b=document.getElementById('settingsBtn');" +
            "if(!b){" +
              "var top=document.querySelector('.topbar-inner');" +
              "if(top){" +
                "b=document.createElement('button');b.id='settingsBtn';b.className='icon-btn';" +
                "b.setAttribute('aria-label','Настройки подключения');b.title='Настройки подключения';b.textContent='⚙';" +
                "top.appendChild(b);" +
              "}" +
            "}" +
            "if(b&&!b.dataset.nativeBound){b.dataset.nativeBound='1';b.addEventListener('click',function(e){e.preventDefault();e.stopPropagation();NativeApp.openSettings();});}" +
            "var st=document.getElementById('syncText');" +
            "if(st&&location.protocol==='file:'){st.textContent='демо • Google Sheets не подключены';}" +
            "}catch(e){}" +
          "})();";
        webView.evaluateJavascript(script, null);
    }

    private void loadConfiguredApp() {
        String url = prefs.getString(KEY_URL, "").trim();
        fallbackShown = false;
        if (isValidBackendUrl(url)) {
            webView.loadUrl(url);
        } else {
            webView.loadUrl(LOCAL_URL);
            Toast.makeText(this, "Демо-режим. Нажмите ⚙, чтобы подключить Google Sheets.", Toast.LENGTH_LONG).show();
        }
    }

    private boolean isValidBackendUrl(String url) {
        if (url == null) return false;
        String u = url.trim().toLowerCase();
        return u.startsWith("https://") && (u.contains("script.google.com/") || u.contains("script.googleusercontent.com/"));
    }

    private void showSettingsDialog() {
        runOnUiThread(() -> {
            final EditText input = new EditText(MainActivity.this);
            input.setSingleLine(false);
            input.setMinLines(2);
            input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
            input.setHint("https://script.google.com/macros/s/.../exec");
            input.setText(prefs.getString(KEY_URL, ""));
            int pad = dp(18);
            input.setPadding(pad, pad, pad, pad);

            AlertDialog dialog = new AlertDialog.Builder(MainActivity.this)
                .setTitle("Подключение Google Sheets")
                .setMessage("Вставьте ссылку веб-приложения Google Apps Script (/exec). После сохранения приложение будет работать с вашей таблицей.")
                .setView(input)
                .setNegativeButton("Отмена", null)
                .setNeutralButton("Демо", (d, w) -> {
                    prefs.edit().remove(KEY_URL).apply();
                    webView.loadUrl(LOCAL_URL);
                })
                .setPositiveButton("Подключить", null)
                .create();

            dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String url = input.getText().toString().trim();
                if (!isValidBackendUrl(url)) {
                    input.setError("Нужна HTTPS-ссылка Google Apps Script, заканчивающаяся на /exec");
                    return;
                }
                prefs.edit().putString(KEY_URL, url).apply();
                dialog.dismiss();
                webView.loadUrl(url);
                Toast.makeText(MainActivity.this, "Подключение сохранено", Toast.LENGTH_SHORT).show();
            }));
            dialog.show();
        });
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    public class NativeBridge {
        @JavascriptInterface
        public void openSettings() {
            showSettingsDialog();
        }

        @JavascriptInterface
        public String getBackendUrl() {
            return prefs.getString(KEY_URL, "");
        }

        @JavascriptInterface
        public boolean isAndroidApp() {
            return true;
        }
    }
}
